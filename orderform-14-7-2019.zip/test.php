<?php 
#- MySQL-Input-Chinese-UTF8.php
#- Copyright (c) 2007-2019 HerongYang.com, All Rights Reserved.
#
  header('Content-Type: text/html; charset=utf-8');
  print('<html><head>');
  print('<meta http-equiv="Content-Type"'.
    ' content="text/html; charset=utf-8"/>');
  print('</head><body>'."\n");

# Default input text
  $input = '电视机/電視機';
  $input_hex = 'E794B5E8A786E69CBA2FE99BBBE8A696E6A99F'; 

# Form submit detection
  $submit = isset($_REQUEST["Submit"]);

# Process form input data
  if ($submit) {
    if (isset($_REQUEST["Input"])) {
      $input = $_REQUEST["Input"];
    }
    $con = mysqli_connect("localhost", "superpvcworks_order", "!lYa$v{=$iAg");
    $ok = mysqli_select_db($con, "superpvcworks_order");
    $commodity = "Input Chinese UTF-8";

#   Set character_set_client and character_set_connection
    mysqli_query($con, "SET character_set_client=utf8");
    mysqli_query($con, "SET character_set_connection=utf8");

#   Delete the record
    $sql = "DELETE FROM orderItems WHERE commodity ='$commodity'";
    mysqli_query($con, $sql);

#   Build the SQL INSERT statement
    $sql = <<<END_OF_MESSAGE
INSERT INTO orderItems (commodity, String_ASCII, 
    String_Latin1, String_UTF8, String_GBK, String_Big5)
  VALUES ('$commodity', null, null, '$input', null, null);
END_OF_MESSAGE;

#   Run the SQL statement
    mysqli_query($con, $sql);

    mysqli_close($con); 
  }

# Display form
  print('<form>');
  print('<input type="Text" size="40" maxlength="64"'
   . ' name="Input" value="'.$input.'"/><br/>');
  print('<input type="Submit" name="Submit" value="Submit"/>');
  print('</form>'."\n");

# Generate response
  if ($submit) {
    $con = mysqli_connect("localhost", "superpvcworks_order", "!lYa$v{=$iAg");
    $ok = mysqli_select_db($con, "superpvcworks_order");

#   Set character_set_results
    mysqli_query($con, "SET character_set_results=utf8");

    $sql = "SELECT * FROM orderItems"
      . " WHERE commodity = '$commodity'";
    $res = mysqli_query($con, $sql);
    $output = 'SELECT failed.';
    if ($row = mysqli_fetch_array($res)) {
      $output = $row['String_UTF8'];
    }  
    mysqli_free_result($res);

    print('<pre>'."\n");
    print('Content-Type:'."\n");
    print('  text/html; charset=utf-8'."\n");
    print('You have submitted:'."\n");
    print('  Text = '.$input."\n");
    print('  Text in HEX = '.strtoupper(bin2hex($input))."\n");
    print('  Default HEX = '.$input_hex."\n");
    print('Saved and retrieved from database:'."\n");
    print('  Text = '.$output."\n");
    print('  Text in HEX = '.strtoupper(bin2hex($output))."\n");
    print('</pre>'."\n");

    mysqli_close($con); 
  } 

  print('</body></html>');
?>