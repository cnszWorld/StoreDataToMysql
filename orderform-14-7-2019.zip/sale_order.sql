-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2019 at 01:14 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sale_order`
--

-- --------------------------------------------------------

--
-- Table structure for table `commoditycatalog`
--

CREATE TABLE `commoditycatalog` (
  `commodityID` int(12) NOT NULL,
  `commodity` varchar(12) NOT NULL,
  `model` varchar(10) NOT NULL,
  `color` varchar(10) NOT NULL,
  `description` varchar(48) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `commoditycatalog`
--

INSERT INTO `commoditycatalog` (`commodityID`, `commodity`, `model`, `color`, `description`, `price`) VALUES
(1, '\nModel 1#ï¼š', '1', 'black', '', 598),
(2, '\nModel 1#ï¼š', '1', 'black', '', 598),
(3, '\nModel 1#ï¼š', '2', 'white', '', 598);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `orderID` int(12) NOT NULL,
  `phoneNumber` int(12) NOT NULL,
  `customerName` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`orderID`, `phoneNumber`, `customerName`) VALUES
(1, 2147483647, 'Muhammad w'),
(2, 2147483647, 'Ali khan'),
(3, 2147483647, 'Muhammad w');

-- --------------------------------------------------------

--
-- Table structure for table `customeraddress`
--

CREATE TABLE `customeraddress` (
  `orderID` int(12) NOT NULL,
  `phoneNumber` int(12) NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(16) NOT NULL,
  `region` varchar(16) NOT NULL,
  `street` varchar(48) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customeraddress`
--

INSERT INTO `customeraddress` (`orderID`, `phoneNumber`, `province`, `city`, `region`, `street`) VALUES
(1, 2147483647, '19', '9', '0', 'Lahore cantt, Pakistan'),
(2, 2147483647, '19', '9', '0', 'Lahore cantt, Pakistan'),
(3, 2147483647, '17', '10', '0', 'Lahore cantt, Pakistan');

-- --------------------------------------------------------

--
-- Table structure for table `customer_message`
--

CREATE TABLE `customer_message` (
  `orderID` int(12) NOT NULL,
  `message` varchar(160) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_message`
--

INSERT INTO `customer_message` (`orderID`, `message`) VALUES
(1, 'message'),
(2, 'hi this mesggae'),
(3, 'message is done');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `orderID` int(11) NOT NULL,
  `commodity` varchar(12) NOT NULL,
  `model` varchar(8) NOT NULL,
  `color` varchar(6) NOT NULL,
  `qty` int(5) NOT NULL,
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`orderID`, `commodity`, `model`, `color`, `qty`, `total`) VALUES
(1, '\nModel 1#ï¼š', '1', 'black', 3, 1794),
(2, '\nModel 1#ï¼š', '1', 'black', 2, 1196),
(3, '\nModel 1#ï¼š', '2', 'white', 5, 2990);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `commoditycatalog`
--
ALTER TABLE `commoditycatalog`
  ADD PRIMARY KEY (`commodityID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`orderID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `commoditycatalog`
--
ALTER TABLE `commoditycatalog`
  MODIFY `commodityID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
