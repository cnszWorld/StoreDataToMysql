! function(e) {
    function t(o) {
        if (n[o]) return n[o].exports;
        var r = n[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return e[o].call(r.exports, r, r.exports, t), r.l = !0, r.exports
    }
    var n = {};
    t.m = e, t.c = n, t.i = function(e) {
        return e
    }, t.d = function(e, n, o) {
        t.o(e, n) || Object.defineProperty(e, n, {
            configurable: !1,
            enumerable: !0,
            get: o
        })
    }, t.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return t.d(n, "a", n), n
    }, t.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, t.p = "/dist/", t(t.s = 916)
}({
    108: function(e, t, n) {
        "use strict";
        var o = n(62);
        t.a = function() {
            function e(e, t) {
                o.a.removeClass(c, "hide"), d.innerHTML = e, setTimeout(function() {
                    o.a.addClass(c, "hide")
                }, t || 3e3)
            }

            function t(e, t) {
                o.a.removeClass(l, "hide"), l.querySelector(".weui-toast__content").innerHTML = e, setTimeout(function() {
                    o.a.addClass(l, "hide")
                }, t || 3e3)
            }

            function n(e, t) {
                o.a.removeClass(p, "hide"), f.innerText = e, setTimeout(function() {
                    o.a.addClass(p, "hide")
                }, t || 3e3)
            }

            function r(e) {
                o.a.removeClass(u, "hide"), setTimeout(function() {
                    o.a.addClass(u, "hide")
                }, 3e4)
            }

            function i() {
                o.a.addClass(u, "hide")
            }

            function a(e) {
                var t = m.querySelector(".weui_dialog_bd"),
                    n = m.querySelector(".weui_btn_dialog"),
                    r = n.cloneNode(!0);
                t.innerText = e.message, n.parentNode.replaceChild(r, n), o.a.removeClass(m, "hide"), r.addEventListener("click", function() {
                    e.onOk && e.onOk(), o.a.addClass(m, "hide")
                })
            }

            function s(e) {
                var t = h.querySelector(".weui_btn_dialog"),
                    n = h.querySelector(".weui_mask"),
                    r = t.cloneNode(!0);
                t.parentNode.replaceChild(r, t), o.a.removeClass(h, "hide"), r.addEventListener("click", function() {
                    e.onOk && e.onOk(), o.a.addClass(h, "hide")
                }), n.addEventListener("click", function() {
                    o.a.addClass(h, "hide")
                })
            }
            var u = document.querySelector("#loading-toast"),
                c = document.querySelector("#toast"),
                l = document.querySelector("#whiteToast"),
                d = document.querySelector("#toast-message"),
                p = document.querySelector("#success-toast"),
                f = document.querySelector("#success-toast-message"),
                m = document.querySelector(".weui_dialog_alert"),
                h = document.querySelector(".order-success-dialog");
            return {
                toast: e,
                whiteToast: t,
                success: n,
                loading: r,
                hideLoading: i,
                alert: a,
                showOrderSubmitSuccessDialog: s
            }
        }()
    },
    154: function(e, t, n) {
        "use strict";
        t.a = {
            success: 1,
            needToRefresh: 114004,
            smsVerifyError: 114002,
            couponError: 114003,
            tokenOutOfTime: 30007,
            greyError: 120001,
            needSmsVerify: 114005
        }
    },
    168: function(e, t, n) {
        "use strict";
        t.a = {
            mobile: /^1\d{10}$/,
            phone: /(^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$)|(^((0\d{2,3}))(\d{7,8})(-(\d{3,}))?$)/,
            contact: /(^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$)|(^((0\d{2,3}))(\d{7,8})(-(\d{3,}))?$)|(^0?1[0-9]{10}$)|(^(400)-(\d{3})-(\d{4})$)|(^(400)(\d{3})(\d{4})$)/,
            zipCode: /^[1-9]\d{5}(?!\d)$/,
            QQ: /^[1-9][0-9]{4,9}$/,
            IP: /^((?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))$/,
            email: /^([a-zA-Z0-9]+[-|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[-|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/,
            certificate: /^\d{6}((\d{2}((0[1-9])|(1[0-2]))[0-3]\d{4})|((19|20)\d{2}((0[1-9])|(1[0-2]))[0-3]\d{4}[0-9xX]?))$/,
            chinese: /^[\u4e00-\u9fa5]+$/,
            letter: /^[a-zA-Z]+$/,
            number: /^[-]?\d+((\.\d+)|(\d*))$/,
            integer: /^[-]?\d+$/,
            positiveInt: /^[1-9][0-9]*$/,
            floating: /^[-]?\d+\.\d+$/,
            positive: /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/,
            positiveFixed2: /^[+]?([0-9]+(?:[\.][0-9]{0,2})?|\.[0-9]{0,2})$/,
            url: /^(https|http):\/\/(((?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))|(([\w-]+).)+[a-zA-Z]{2,6}|localhost)(:[0-9]{1,6})?(\/[\w-]+)*((\/([\w-]+\.)+[\w-]{1,5})|\/)?$/,
            link: /^(https|http):\/\/(((?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))|(([\w-]+).)+[a-zA-Z]{2,6}|localhost)(:[0-9]{1,6})?(\/[\w-]+)*((\/([\w-]+\.)+[\w-]{1,5})|\/)?((\?|\#)\S*)?$/,
            id_number: /^(\d{18,18}|\d{15,15}|\d{17,17}[x,X])$/
        }
    },
    379: function(e, t, n) {
        "use strict";
        t.a = {
            isMpShareClose: function() {
                return window.EC.systemConfig && 1 == window.EC.systemConfig.play_close_mp_share
            },
            isMarqueeClose: function() {
                return window.EC.systemConfig && 1 == window.EC.systemConfig.play_close_marquee
            },
            isIpLocationClose: function() {
                return window.EC.systemConfig && 1 == window.EC.systemConfig.play_close_ip_location
            },
            isRefreshTokenClose: function() {
                return window.EC.systemConfig && 1 == window.EC.systemConfig.play_close_refresh_token
            }
        }
    },
    555: function(e, t, n) {
        var o, r;
        ! function(i) {
            var a = !1;
            if (o = i, void 0 !== (r = "function" == typeof o ? o.call(t, n, t, e) : o) && (e.exports = r), a = !0, e.exports = i(), a = !0, !a) {
                var s = window.Cookies,
                    u = window.Cookies = i();
                u.noConflict = function() {
                    return window.Cookies = s, u
                }
            }
        }(function() {
            function e() {
                for (var e = 0, t = {}; e < arguments.length; e++) {
                    var n = arguments[e];
                    for (var o in n) t[o] = n[o]
                }
                return t
            }

            function t(n) {
                function o(t, r, i) {
                    var a;
                    if ("undefined" != typeof document) {
                        if (arguments.length > 1) {
                            if (i = e({
                                    path: "/"
                                }, o.defaults, i), "number" == typeof i.expires) {
                                var s = new Date;
                                s.setMilliseconds(s.getMilliseconds() + 864e5 * i.expires), i.expires = s
                            }
                            i.expires = i.expires ? i.expires.toUTCString() : "";
                            try {
                                a = JSON.stringify(r), /^[\{\[]/.test(a) && (r = a)
                            } catch (e) {}
                            r = n.write ? n.write(r, t) : encodeURIComponent(String(r)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent), t = encodeURIComponent(String(t)), t = t.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent), t = t.replace(/[\(\)]/g, escape);
                            var u = "";
                            for (var c in i) i[c] && (u += "; " + c, !0 !== i[c] && (u += "=" + i[c]));
                            return document.cookie = t + "=" + r + u
                        }
                        t || (a = {});
                        for (var l = document.cookie ? document.cookie.split("; ") : [], d = /(%[0-9A-Z]{2})+/g, p = 0; p < l.length; p++) {
                            var f = l[p].split("="),
                                m = f.slice(1).join("=");
                            this.json || '"' !== m.charAt(0) || (m = m.slice(1, -1));
                            try {
                                var h = f[0].replace(d, decodeURIComponent);
                                if (m = n.read ? n.read(m, h) : n(m, h) || m.replace(d, decodeURIComponent), this.json) try {
                                    m = JSON.parse(m)
                                } catch (e) {}
                                if (t === h) {
                                    a = m;
                                    break
                                }
                                t || (a[h] = m)
                            } catch (e) {}
                        }
                        return a
                    }
                }
                return o.set = o, o.get = function(e) {
                    return o.call(o, e)
                }, o.getJSON = function() {
                    return o.apply({
                        json: !0
                    }, [].slice.call(arguments))
                }, o.defaults = {}, o.remove = function(t, n) {
                    o(t, "", e(n, {
                        expires: -1
                    }))
                }, o.withConverter = t, o
            }
            return t(function() {})
        })
    },
    570: function(e, t, n) {
        "use strict";
        var o = n(62),
            r = n(108),
            i = n(914),
            a = n(888),
            s = n(886);
        t.a = function() {
            function e() {
                var e = 0,
                    t = 0,
                    n = 0,
                    r = parseFloat(c()),
                    i = parseInt(a.a.getCount()),
                    u = null;
                if (!isNaN(r) && !isNaN(i)) {
                    e = r * i, t = r * i;
                    for (var l = 0; l < s.a.currentCoupon.length; l++) {
                        var d = s.a.currentCoupon[l],
                            p = parseFloat(d.full),
                            f = parseFloat(d.minus);
                        if (!isNaN(p) && !isNaN(f) && p <= r && f <= r * s.a.couponPercent) {
                            var m = (r - f) * i;
                            m < t && (n = f * i, t = m, s.a.updateCouponIndex(d), u = d)
                        }
                    }
                }
                u || (s.a.couponIndex = -1), t = +parseFloat(t.toPrecision(12)), u && y && w && C && S ? (o.a.removeClass(y, "hide"), S.innerText = t, C.innerText = n, 0 == u.full ? w.innerText = "减" + u.minus + "元" : w.innerText = "满" + u.full + "减" + u.minus + "元") : y && o.a.addClass(y, "hide"), e = +parseFloat(e.toPrecision(12)), h = Math.max(t, 0), S.innerText = h
            }

            function t() {
                var e = !0,
                    t = "";
                return o.a.forEach(p, function(n) {
                    var i = n.getAttribute("data-attribute");
                    i.slice(0, 1) == m && void 0 == f[i] && (o.a.removeClass(document.querySelector('[data-attribute-validate="' + i + '"]'), "hide"), e && ("" == t && (t = i), r.a.toast(document.querySelector('[data-attribute-validate="' + i + '"]').innerText)), e = !1)
                }), "" != t && o.a.scrollToElement("#attribute-name-" + t), e
            }

            function n() {
                o.a.removeClass(p, "active"), m = 0, o.a.addAssignedClass(l, "active", m), o.a.removeAssignedClass(d, "hide", m), f = {}, o.a.addClass(document.querySelectorAll(".pic-prop[data-index]"), "hide")
            }

            function u() {
                var e = JSON.parse(JSON.stringify(v))[m];
                return (e.productList || []).forEach(function(e, t) {
                    (e.productAttributeList || []).forEach(function(e, n) {
                        e.attributeValue = f[[m, t, n].join("_")]
                    })
                }), e
            }

            function c() {
                return l[m] ? +l[m].getAttribute("data-price") : 0
            }
            var l = document.querySelectorAll("[data-package]"),
                d = document.querySelectorAll("[data-detail]"),
                p = document.querySelectorAll("[data-attribute]"),
                f = {},
                m = 0,
                h = 0,
                g = new i.a,
                v = o.a.isString(window.EC.packageList) ? JSON.parse(window.EC.packageList.replace(/&quot;/g, '"')) : window.EC.packageList,
                y = document.querySelector("#formCoupon"),
                w = document.querySelector("#selectedCoupon"),
                C = document.querySelector("#totalMinus"),
                S = document.querySelector("#couponTotalPrice");
            return {
                init: function() {
                    o.a.on(l, "click", function() {
                        var t = parseInt(this.getAttribute("data-package"));
                        isNaN(t) || (o.a.addAssignedClass(l, "active", t), o.a.removeAssignedClass(d, "hide", t), m = t, e())
                    }), o.a.on(p, "click", function() {
                        var e = this.getAttribute("data-attribute"),
                            t = this.getAttribute("data-value"),
                            n = parseInt(this.getAttribute("data-index")),
                            r = e.split("_");
                        if (3 == r.length) {
                            var i = v[r[0]].productList[r[1]].productAttributeList[r[2]];
                            if ("txtpic" == i.module) {
                                var a = i.attributeValue,
                                    s = document.querySelector('.pic-prop[data-index="' + r[0] + "_" + r[1] + '"]');
                                s && (s.style["background-image"] = "url(" + a[n].pic + ")", o.a.removeClass(s, "hide"))
                            }
                        }
                        o.a.addClass(document.querySelector('[data-attribute-validate="' + e + '"]'), "hide"), o.a.addAssignedClass(document.querySelectorAll('[data-attribute="' + e + '"]'), "active", "data-value", t), f[e] = t
                    }), e()
                },
                validate: t,
                getPackagePrice: c,
                clear: n,
                getPackageInfo: u,
                updatePrice: e,
                getPay: function() {
                    return h
                },
                listen: function(e, t) {
                    g.listen(e, t)
                }
            }
        }()
    },
    62: function(e, t, n) {
        "use strict";
        var o = n(732),
            r = n.n(o),
            i = n(108),
            a = n(154),
            s = n(379),
            u = n(555),
            c = n.n(u);
        t.a = {
            MAX_CITOKEN_LIFE: 3e5,
            citoken: window.EC.citoken,
            isArray: function(e) {
                return "[object Array]" == Object.prototype.toString.call(e)
            },
            isObject: function(e) {
                return "[object Object]" == Object.prototype.toString.call(e)
            },
            isBoolean: function(e) {
                return "[object Boolean]" == Object.prototype.toString.call(e)
            },
            isNumber: function(e) {
                return "[object Number]" == Object.prototype.toString.call(e)
            },
            isString: function(e) {
                return "[object String]" == Object.prototype.toString.call(e)
            },
            isWX: function() {
                return /MicroMessenger/i.test(navigator.userAgent)
            },
            isQQ: function() {
                return /QQ/i.test(navigator.userAgent)
            },
            getOS: function() {
                var e = navigator.userAgent || navigator.vendor || window.opera;
                return /windows phone/i.test(e) ? "others" : /android/i.test(e) ? "Android" : /iPad|iPhone|iPod/.test(e) && !window.MSStream ? "iOS" : "others"
            },
            getConnectionType: function() {
                var e = window.navigator.connection || window.navigator.mozConnection || window.navigator.webkitConnection || {};
                return e.type || e.effectiveType || "unknown"
            },
            isWIFI: function() {
                return "wifi" == this.getConnectionType().toLowerCase()
            },
            getDomain: function(e) {
                return e = e || window.location.hostname, e = e.substring(e.lastIndexOf(".", e.lastIndexOf(".") - 1) + 1), "flzhan.cn" == e ? "ec.flzhan.cn" : e
            },
            setCookie: function(e, t, n) {
                c.a.set(e, t, {
                    expires: n,
                    domain: this.getDomain(),
                    path: "/"
                })
            },
            removeCookie: function(e) {
                c.a.remove(e, {
                    domain: this.getDomain(),
                    path: "/"
                })
            },
            getCookie: function(e, t) {
                var n = c.a.get(e, {
                    domain: this.getDomain()
                });
                if ("json" == t) try {
                    return JSON.parse(n)
                } catch (e) {
                    return null
                }
                return n
            },
            addClass: function(e, t) {
                var n = this,
                    o = this.getNodeList(e);
                this.forEach(o, function(e) {
                    n.hasClass(e, t) || (e.className += " " + t)
                })
            },
            removeClass: function(e, t) {
                var n = this,
                    o = this.getNodeList(e);
                this.forEach(o, function(e) {
                    n.hasClass(e, t) && (e.className = e.className.split(t).join(""))
                })
            },
            addAssignedClass: function(e, t, n, o, r) {
                var i = this,
                    a = this.getNodeList(e);
                this.forEach(a, function(e, a) {
                    /\d+/.test(n) ? (r ? n != a : n == a) ? i.addClass(e, t) : i.removeClass(e, t) : (r ? e.getAttribute(n) != o : e.getAttribute(n) == o) ? i.addClass(e, t) : i.removeClass(e, t)
                })
            },
            removeAssignedClass: function(e, t, n, o) {
                this.addAssignedClass(e, t, n, o, !0)
            },
            on: function(e, t, n) {
                var o = this.getNodeList(e);
                this.forEach(o, function(e) {
                    e.addEventListener(t, function(e) {
                        n && n.call(e.target, e)
                    })
                })
            },
            getStaticDomain: function() {
                return window.EC.staticDomain ? window.EC.staticDomain : ""
            },
            getNodeList: function(e) {
                if (e) return e instanceof NodeList || e instanceof Array ? e : [e]
            },
            hasClass: function(e, t) {
                return e.className.indexOf(t) > -1
            },
            forEach: function(e, t) {
                [].slice.call(e || [], 0).forEach(t)
            },
            isScrolledIntoView: function(e, t) {
                var n = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
                return e.getBoundingClientRect().top < n + (t || 0)
            },
            offset: function(e) {
                var t = e.getBoundingClientRect(),
                    n = 0 == window.pageXOffset ? 0 : window.pageXOffset || document.documentElement.scrollLeft,
                    o = 0 == window.pageYOffset ? 0 : window.pageYOffset || document.documentElement.scrollTop;
                return {
                    top: t.top + o,
                    left: t.left + n
                }
            },
            loadScript: function(e, t) {
                var n = document.createElement("script");
                n.type = "text/javascript", n.readyState ? n.onreadystatechange = function() {
                    "loaded" != n.readyState && "complete" != n.readyState || (n.onreadystatechange = null, t && t())
                } : n.onload = function() {
                    t && t()
                }, n.src = e, document.body.appendChild(n)
            },
            getWindowSize: function() {
                var e = window,
                    t = document,
                    n = t.documentElement,
                    o = t.getElementsByTagName("body")[0];
                return {
                    width: e.innerWidth || n.clientWidth || o.clientWidth,
                    height: e.innerHeight || n.clientHeight || o.clientHeight
                }
            },
            trim: function(e) {
                return e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "")
            },
            reportByImg: function(e) {
                var t = new Image;
                t.onload = t.onerror = function() {
                    t = null
                }, t.src = e + (e.indexOf("?") > -1 ? "&" : "?") + "r=" + (new Date).getTime()
            },
            getUrlParam: function(e, t) {
                var n, o, r = t || location.href,
                    i = r.indexOf("?"),
                    a = {};
                for (-1 != i ? (r = r.substring(i + 1), o = r.split("#")[0].split("&")) : o = [], n = 0; n < o.length; ++n) o[n] = o[n].split("="), a[o[n][0]] = a[o[n][0].toLowerCase()] = o[n][1];
                return e ? a[e] : a
            },
            reportJsError: function(e) {
                var t = encodeURIComponent(window.location.href);
                "undefined" != typeof maya && maya.report(e, t, 0, 4, 2), this.reportByImg("//" + window.EC.statHost + "/stat/report/jsalarm?msg=" + e + "&url=" + t + "&ua=" + encodeURIComponent(window.navigator.userAgent) + "&timestamp=" + window.EC.timestamp + "&citoken=" + this.getCiToken())
            },
            getCompleteUrl: function(e) {
                var t = window.location.origin,
                    n = window.location.pathname;
                return /^https?:\/\//.test(e) ? e : /^\//.test(e) ? t + e : t + n.replace(/(?:\/)\w*$/, "/" + e)
            },
            isGrey: function() {
                return c.a && c.a.get("fygrey") && 1 == c.a.get("fygrey")
            },
            getGrey: function() {
                return c.a.get("fygrey")
            },
            replaceUrlParam: function(e, t, n) {
                return e.replace(new RegExp(t + "=.*?($|&)"), function(e, o) {
                    return t + "=" + n + ("&" == o ? "&" : "")
                })
            },
            ajax: function(e, t) {
                e = e || {};
                var n = this,
                    o = e.success,
                    s = e.error,
                    u = e.url;
                return !t && this.isCiTokenOutOfTime() && u.indexOf("getcitoken") < 0 ? void this.getCiTokenFromServer(function() {
                    n.ajax(e, !0)
                }, "ajax") : (this.isGrey() && e.url.indexOf("fygrey=") < 0 && (e.url += (e.url.indexOf("?") < 0 ? "?" : "&") + "fygrey=" + this.getGrey()), window.EC.token && e.url && e.url.indexOf("token=") < 0 && (e.url += (e.url.indexOf("?") < 0 ? "?" : "&") + "token=" + window.EC.token), e.url && e.url.indexOf("citoken=") < 0 && (e.url += (e.url.indexOf("?") < 0 ? "?" : "&") + "citoken=" + this.getCiToken()), e.url && e.url.indexOf("r_id=") < 0 && (e.url += (e.url.indexOf("?") < 0 ? "?" : "&") + "r_id=" + window.EC.rId), window.EC.orderId && e.url && e.url.indexOf("order_id=") < 0 && (e.url += (e.url.indexOf("?") < 0 ? "?" : "&") + "order_id=" + window.EC.orderId), window.EC.timestamp && e.url && e.url.indexOf("timestamp=") < 0 && (e.url += (e.url.indexOf("?") < 0 ? "?" : "&") + "timestamp=" + window.EC.timestamp), this.getUrlParam("_ec_now") && e.url && e.url.indexOf("_ec_now=") < 0 && (e.url += (e.url.indexOf("?") < 0 ? "?" : "&") + "_ec_now=" + this.getUrlParam("_ec_now")), e.success = function(t) {
                    if (t.code == a.a.greyError) i.a.alert({
                        message: t.message,
                        onOk: function() {
                            window.location.reload(!0)
                        }
                    });
                    else if (t.code == a.a.tokenOutOfTime) {
                        var r = e.url.substr(e.url.lastIndexOf("/") + 1).replace(/\?.*/, "");
                        n.getCiTokenFromServer(function() {
                            e.url = u, e.success = o, e.error = s, n.ajax(e, !0)
                        }, r)
                    } else o && o(t)
                }, e.error = function(t) {
                    if (4 == t.readyState && 0 == t.status && e.tryTimes && e.tryTimes > 0) e.tryTimes--, e.url = u, e.success = o, e.error = s, n.ajax(e);
                    else {
                        4 == t.readyState && 0 == t.status && 0 == e.tryTimes && i.a.alert({
                            message: "网络不稳定，请重试"
                        });
                        var r = {
                            readyState: t.readyState,
                            status: t.status,
                            statusText: encodeURIComponent(t.statusText),
                            url: encodeURIComponent(n.getCompleteUrl(e.url)),
                            method: e.method || "get",
                            data: n.isObject(e.data) ? JSON.stringify(e.data) : e.data || ""
                        };
                        n.reportJsError(JSON.stringify(r)), s && s(t)
                    }
                }, e.type = e.type || "json", r()(e))
            },
            runCiTokenTimer: function() {
                var e = this;
                window.setTimeout(function() {
                    e.getCiTokenFromServer(null, "timer"), e.runCiTokenTimer()
                }, 18e4)
            },
            getCiTokenFromServer: function(e, t) {
                var n = this;
                s.a.isRefreshTokenClose() ? e && e() : this.ajax({
                    url: "/token/getcitoken?r=" + Math.random().toString().slice(2) + "&action=" + t,
                    success: function(t) {
                        t.data && t.data.citoken && (n.citoken = t.data.citoken, e && e())
                    },
                    tryTimes: 2
                })
            },
            getCiToken: function() {
                return this.citoken
            },
            isSameDay: function(e, t) {
                return e.getFullYear() === t.getFullYear() && e.getMonth() === t.getMonth() && e.getDate() === t.getDate()
            },
            scrollToElement: function(e) {
                window.location.hash = e
            },
            randomRange: function(e, t) {
                return Math.floor(Math.random() * (t - e + 1)) + e
            },
            hasFirstImage: function() {
                return !(!document.querySelector(".first-image").querySelector("img") && !document.querySelector(".first-image").querySelector("#videoIndexPic"))
            },
            insertAfter: function(e, t) {
                t.parentNode.insertBefore(e, t.nextSibling)
            },
            isCiTokenOutOfTime: function(e) {
                if (!(e = e || this.getCiToken())) return !0;
                var t = e.split("-");
                return !t.length || 3 != t.length || (t = parseInt(t[0] + "000"), Date.now() - t > this.MAX_CITOKEN_LIFE - 3e4)
            },
            formatNumToFixDigit: function(e, t) {
                if (isNaN(e)) return e;
                for (e += ""; e.length < t;) e = "0" + e;
                return e
            }
        }
    },
    732: function(module, exports, __webpack_require__) {
        var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;
        ! function(e, t, n) {
            void 0 !== module && module.exports ? module.exports = n() : (__WEBPACK_AMD_DEFINE_FACTORY__ = n, void 0 !== (__WEBPACK_AMD_DEFINE_RESULT__ = "function" == typeof __WEBPACK_AMD_DEFINE_FACTORY__ ? __WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module) : __WEBPACK_AMD_DEFINE_FACTORY__) && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))
        }(0, 0, function() {
            function succeed(e) {
                var t = protocolRe.exec(e.url);
                return t = t && t[1] || context.location.protocol, httpsRe.test(t) ? twoHundo.test(e.request.status) : !!e.request.response
            }

            function handleReadyState(e, t, n) {
                return function() {
                    return e._aborted ? n(e.request) : e._timedOut ? n(e.request, "Request is aborted: timeout") : void(e.request && 4 == e.request[readyState] && (e.request.onreadystatechange = noop, succeed(e) ? t(e.request) : n(e.request)))
                }
            }

            function setHeaders(e, t) {
                var n, o = t.headers || {};
                o.Accept = o.Accept || defaultHeaders.accept[t.type] || defaultHeaders.accept["*"];
                var r = "undefined" != typeof FormData && t.data instanceof FormData;
                t.crossOrigin || o[requestedWith] || (o[requestedWith] = defaultHeaders.requestedWith), o[contentType] || r || (o[contentType] = t.contentType || defaultHeaders.contentType);
                for (n in o) o.hasOwnProperty(n) && "setRequestHeader" in e && e.setRequestHeader(n, o[n])
            }

            function setCredentials(e, t) {
                void 0 !== t.withCredentials && void 0 !== e.withCredentials && (e.withCredentials = !!t.withCredentials)
            }

            function generalCallback(e) {
                lastValue = e
            }

            function urlappend(e, t) {
                return e + (/\?/.test(e) ? "&" : "?") + t
            }

            function handleJsonp(e, t, n, o) {
                var r = uniqid++,
                    i = e.jsonpCallback || "callback",
                    a = e.jsonpCallbackName || reqwest.getcallbackPrefix(r),
                    s = new RegExp("((^|\\?|&)" + i + ")=([^&]+)"),
                    u = o.match(s),
                    c = doc.createElement("script"),
                    l = 0,
                    d = -1 !== navigator.userAgent.indexOf("MSIE 10.0");
                return u ? "?" === u[3] ? o = o.replace(s, "$1=" + a) : a = u[3] : o = urlappend(o, i + "=" + a), context[a] = generalCallback, c.type = "text/javascript", c.src = o, c.async = !0, void 0 === c.onreadystatechange || d || (c.htmlFor = c.id = "_reqwest_" + r), c.onload = c.onreadystatechange = function() {
                    if (c[readyState] && "complete" !== c[readyState] && "loaded" !== c[readyState] || l) return !1;
                    c.onload = c.onreadystatechange = null, c.onclick && c.onclick(), t(lastValue), lastValue = void 0, head.removeChild(c), l = 1
                }, head.appendChild(c), {
                    abort: function() {
                        c.onload = c.onreadystatechange = null, n({}, "Request is aborted: timeout", {}), lastValue = void 0, head.removeChild(c), l = 1
                    }
                }
            }

            function getRequest(e, t) {
                var n, o = this.o,
                    r = (o.method || "GET").toUpperCase(),
                    i = "string" == typeof o ? o : o.url,
                    a = !1 !== o.processData && o.data && "string" != typeof o.data ? reqwest.toQueryString(o.data) : o.data || null,
                    s = !1;
                return "jsonp" != o.type && "GET" != r || !a || (i = urlappend(i, a), a = null), "jsonp" == o.type ? handleJsonp(o, e, t, i) : (n = o.xhr && o.xhr(o) || xhr(o), n.open(r, i, !1 !== o.async), setHeaders(n, o), setCredentials(n, o), context[xDomainRequest] && n instanceof context[xDomainRequest] ? (n.onload = e, n.onerror = t, n.onprogress = function() {}, s = !0) : n.onreadystatechange = handleReadyState(this, e, t), o.before && o.before(n), s ? setTimeout(function() {
                    n.send(a)
                }, 200) : n.send(a), n)
            }

            function Reqwest(e, t) {
                this.o = e, this.fn = t, init.apply(this, arguments)
            }

            function setType(e) {
                if (null !== e) return e.match("json") ? "json" : e.match("javascript") ? "js" : e.match("text") ? "html" : e.match("xml") ? "xml" : void 0
            }

            function init(o, fn) {
                function complete(e) {
                    for (o.timeout && clearTimeout(self.timeout), self.timeout = null; self._completeHandlers.length > 0;) self._completeHandlers.shift()(e)
                }

                function success(resp) {
                    var type = o.type || resp && setType(resp.getResponseHeader("Content-Type"));
                    resp = "jsonp" !== type ? self.request : resp;
                    var filteredResponse = globalSetupOptions.dataFilter(resp.responseText, type),
                        r = filteredResponse;
                    try {
                        resp.responseText = r
                    } catch (e) {}
                    if (r) switch (type) {
                        case "json":
                            try {
                                resp = context.JSON ? context.JSON.parse(r) : eval("(" + r + ")")
                            } catch (e) {
                                return error(resp, "Could not parse JSON in response", e)
                            }
                            break;
                        case "js":
                            resp = eval(r);
                            break;
                        case "html":
                            resp = r;
                            break;
                        case "xml":
                            resp = resp.responseXML && resp.responseXML.parseError && resp.responseXML.parseError.errorCode && resp.responseXML.parseError.reason ? null : resp.responseXML
                    }
                    for (self._responseArgs.resp = resp, self._fulfilled = !0, fn(resp), self._successHandler(resp); self._fulfillmentHandlers.length > 0;) resp = self._fulfillmentHandlers.shift()(resp);
                    complete(resp)
                }

                function timedOut() {
                    self._timedOut = !0, self.request.abort()
                }

                function error(e, t, n) {
                    for (e = self.request, self._responseArgs.resp = e, self._responseArgs.msg = t, self._responseArgs.t = n, self._erred = !0; self._errorHandlers.length > 0;) self._errorHandlers.shift()(e, t, n);
                    complete(e)
                }
                this.url = "string" == typeof o ? o : o.url, this.timeout = null, this._fulfilled = !1, this._successHandler = function() {}, this._fulfillmentHandlers = [], this._errorHandlers = [], this._completeHandlers = [], this._erred = !1, this._responseArgs = {};
                var self = this;
                fn = fn || function() {}, o.timeout && (this.timeout = setTimeout(function() {
                    timedOut()
                }, o.timeout)), o.success && (this._successHandler = function() {
                    o.success.apply(o, arguments)
                }), o.error && this._errorHandlers.push(function() {
                    o.error.apply(o, arguments)
                }), o.complete && this._completeHandlers.push(function() {
                    o.complete.apply(o, arguments)
                }), this.request = getRequest.call(this, success, error)
            }

            function reqwest(e, t) {
                return new Reqwest(e, t)
            }

            function normalize(e) {
                return e ? e.replace(/\r?\n/g, "\r\n") : ""
            }

            function serial(e, t) {
                var n, o, r, i, a = e.name,
                    s = e.tagName.toLowerCase(),
                    u = function(e) {
                        e && !e.disabled && t(a, normalize(e.attributes.value && e.attributes.value.specified ? e.value : e.text))
                    };
                if (!e.disabled && a) switch (s) {
                    case "input":
                        /reset|button|image|file/i.test(e.type) || (n = /checkbox/i.test(e.type), o = /radio/i.test(e.type), r = e.value, (!(n || o) || e.checked) && t(a, normalize(n && "" === r ? "on" : r)));
                        break;
                    case "textarea":
                        t(a, normalize(e.value));
                        break;
                    case "select":
                        if ("select-one" === e.type.toLowerCase()) u(e.selectedIndex >= 0 ? e.options[e.selectedIndex] : null);
                        else
                            for (i = 0; e.length && i < e.length; i++) e.options[i].selected && u(e.options[i])
                }
            }

            function eachFormElement() {
                var e, t, n = this;
                for (t = 0; t < arguments.length; t++) e = arguments[t], /input|select|textarea/i.test(e.tagName) && serial(e, n),
                    function(e, t) {
                        var o, r, i;
                        for (o = 0; o < t.length; o++)
                            for (i = e[byTag](t[o]), r = 0; r < i.length; r++) serial(i[r], n)
                    }(e, ["input", "select", "textarea"])
            }

            function serializeQueryString() {
                return reqwest.toQueryString(reqwest.serializeArray.apply(null, arguments))
            }

            function serializeHash() {
                var e = {};
                return eachFormElement.apply(function(t, n) {
                    t in e ? (e[t] && !isArray(e[t]) && (e[t] = [e[t]]), e[t].push(n)) : e[t] = n
                }, arguments), e
            }

            function buildParams(e, t, n, o) {
                var r, i, a, s = /\[\]$/;
                if (isArray(t))
                    for (i = 0; t && i < t.length; i++) a = t[i], n || s.test(e) ? o(e, a) : buildParams(e + "[" + ("object" == typeof a ? i : "") + "]", a, n, o);
                else if (t && "[object Object]" === t.toString())
                    for (r in t) buildParams(e + "[" + r + "]", t[r], n, o);
                else o(e, t)
            }
            var context = this;
            if ("window" in context) var doc = document,
                byTag = "getElementsByTagName",
                head = doc[byTag]("head")[0];
            else {
                var XHR2;
                try {
                    XHR2 = __webpack_require__(882)
                } catch (e) {
                    throw new Error("Peer dependency `xhr2` required! Please npm install xhr2")
                }
            }
            var httpsRe = /^http/,
                protocolRe = /(^\w+):\/\//,
                twoHundo = /^(20\d|1223)$/,
                readyState = "readyState",
                contentType = "Content-Type",
                requestedWith = "X-Requested-With",
                uniqid = 0,
                callbackPrefix = "reqwest_" + +new Date,
                lastValue, xmlHttpRequest = "XMLHttpRequest",
                xDomainRequest = "XDomainRequest",
                noop = function() {},
                isArray = "function" == typeof Array.isArray ? Array.isArray : function(e) {
                    return e instanceof Array
                },
                defaultHeaders = {
                    contentType: "application/x-www-form-urlencoded",
                    requestedWith: xmlHttpRequest,
                    accept: {
                        "*": "text/javascript, text/html, application/xml, text/xml, */*",
                        xml: "application/xml, text/xml",
                        html: "text/html",
                        text: "text/plain",
                        json: "application/json, text/javascript",
                        js: "application/javascript, text/javascript"
                    }
                },
                xhr = function(e) {
                    if (!0 === e.crossOrigin) {
                        var t = context[xmlHttpRequest] ? new XMLHttpRequest : null;
                        if (t && "withCredentials" in t) return t;
                        if (context[xDomainRequest]) return new XDomainRequest;
                        throw new Error("Browser does not support cross-origin requests")
                    }
                    return context[xmlHttpRequest] ? new XMLHttpRequest : XHR2 ? new XHR2 : new ActiveXObject("Microsoft.XMLHTTP")
                },
                globalSetupOptions = {
                    dataFilter: function(e) {
                        return e
                    }
                };
            return Reqwest.prototype = {
                abort: function() {
                    this._aborted = !0, this.request.abort()
                },
                retry: function() {
                    init.call(this, this.o, this.fn)
                },
                then: function(e, t) {
                    return e = e || function() {}, t = t || function() {}, this._fulfilled ? this._responseArgs.resp = e(this._responseArgs.resp) : this._erred ? t(this._responseArgs.resp, this._responseArgs.msg, this._responseArgs.t) : (this._fulfillmentHandlers.push(e), this._errorHandlers.push(t)), this
                },
                always: function(e) {
                    return this._fulfilled || this._erred ? e(this._responseArgs.resp) : this._completeHandlers.push(e), this
                },
                fail: function(e) {
                    return this._erred ? e(this._responseArgs.resp, this._responseArgs.msg, this._responseArgs.t) : this._errorHandlers.push(e), this
                },
                catch: function(e) {
                    return this.fail(e)
                }
            }, reqwest.serializeArray = function() {
                var e = [];
                return eachFormElement.apply(function(t, n) {
                    e.push({
                        name: t,
                        value: n
                    })
                }, arguments), e
            }, reqwest.serialize = function() {
                if (0 === arguments.length) return "";
                var e, t, n = Array.prototype.slice.call(arguments, 0);
                return e = n.pop(), e && e.nodeType && n.push(e) && (e = null), e && (e = e.type), t = "map" == e ? serializeHash : "array" == e ? reqwest.serializeArray : serializeQueryString, t.apply(null, n)
            }, reqwest.toQueryString = function(e, t) {
                var n, o, r = t || !1,
                    i = [],
                    a = encodeURIComponent,
                    s = function(e, t) {
                        t = "function" == typeof t ? t() : null == t ? "" : t, i[i.length] = a(e) + "=" + a(t)
                    };
                if (isArray(e))
                    for (o = 0; e && o < e.length; o++) s(e[o].name, e[o].value);
                else
                    for (n in e) e.hasOwnProperty(n) && buildParams(n, e[n], r, s);
                return i.join("&").replace(/%20/g, "+")
            }, reqwest.getcallbackPrefix = function() {
                return callbackPrefix
            }, reqwest.compat = function(e, t) {
                return e && (e.type && (e.method = e.type) && delete e.type, e.dataType && (e.type = e.dataType), e.jsonpCallback && (e.jsonpCallbackName = e.jsonpCallback) && delete e.jsonpCallback, e.jsonp && (e.jsonpCallback = e.jsonp)), new Reqwest(e, t)
            }, reqwest.ajaxSetup = function(e) {
                e = e || {};
                for (var t in e) globalSetupOptions[t] = e[t]
            }, reqwest
        })
    },
    882: function(e, t) {},
    886: function(e, t, n) {
        "use strict";
        var o = n(62),
            r = n(570),
            i = n(108),
            a = n(555),
            s = n.n(a);
        t.a = {
            couponSetting: null,
            togetherId: parseInt(o.a.getUrlParam("together_id")),
            currentCoupon: [],
            couponIndex: -1,
            couponPercent: .25,
            couponListWrapper: document.querySelector("#couponWrapper"),
            couponDialog: document.querySelector(".coupon-dialog"),
            couponLayer: document.querySelector(".coupon-mask"),
            init: function() {
                if (this.couponListWrapper) {
                    this.couponSetting = o.a.isString(window.EC.coupon) ? JSON.parse(window.EC.coupon.replace(/&quot;/g, '"')) : window.EC.coupon, this.getCoupon(), this.initDialogAndlayer(), this.currentCoupon = [].concat(this.couponSetting.list), this.update(), o.a.removeClass(this.couponListWrapper, "hide"), o.a.on(this.couponListWrapper, "click", function() {
                        1 == this.couponSetting.list.length ? this.addCoupon(this.couponSetting.list[0]) : this.showCouponDialog()
                    }.bind(this));
                    var e = document.querySelector(".coupon-done-btn");
                    e && e.addEventListener("click", function(e) {
                        return this.hideCouponDialog(), e.stopPropagation(), e.preventDefault(), !1
                    }.bind(this));
                    var t = document.querySelectorAll(".coupon-dialog .count-1");
                    o.a.on(t, "click", function(e) {
                        var n = e.currentTarget,
                            o = [].indexOf.call(t, n);
                        o > -1 && this.couponSetting && this.couponSetting.list.length > o && this.addCoupon(this.couponSetting.list[o])
                    }.bind(this))
                }
            },
            initDialogAndlayer: function() {
                if (this.couponLayer && this.couponDialog) {
                    this.couponLayer.querySelector(".coupon-wrapper").innerHTML = this.couponListWrapper.innerHTML, this.couponDialog.querySelector(".coupon-wrapper").innerHTML = this.couponListWrapper.innerHTML;
                    for (var e = this.couponLayer.querySelectorAll(".count-1,.count-2,.count-3,.count-4"), t = this.couponDialog.querySelectorAll(".count-1,.count-2,.count-3,.count-4"), n = 0; n < t.length; n++) e[n].setAttribute("class", "count-1"), t[n].setAttribute("class", "count-1");
                    for (var r = this.couponLayer.querySelectorAll(".close-btn"), i = 0; i < r.length; i++) r[i].addEventListener("click", this.closeLayer.bind(this));
                    this.couponLayer.querySelector(".coupon-single-use-btn").addEventListener("click", this.closeLayer.bind(this)), this.currentCoupon.length || o.a.removeClass(this.couponLayer, "hide")
                }
            },
            closeLayer: function(e) {
                return o.a.addClass(this.couponLayer, "hide"), e.stopPropagation(), e.preventDefault(), !1
            },
            showCouponDialog: function() {
                this.couponDialog.style.bottom = 0
            },
            hideCouponDialog: function() {
                this.couponDialog.style.bottom = "-800px"
            },
            getCouponId: function() {
                return this.couponSetting ? this.couponSetting.id : ""
            },
            getKey: function() {
                return "coupon_" + ("together" != window.EC.ecfrom || isNaN(this.togetherId) || window.EC.isTogether ? window.EC.gId : this.togetherId)
            },
            getCoupon: function() {
                var e = this.getKey(),
                    t = o.a.getCookie(e, "json");
                t && t.time && (o.a.isSameDay(new Date(t.time), new Date) ? this.currentCoupon = t.list || [] : o.a.removeCookie(e))
            },
            addCoupon: function(e) {
                if (this.couponExist(e)) return void(window.EC.isTogether ? i.a.toast("当前优惠券已领取", 3e3) : location.href = "#fill-forms");
                this.currentCoupon.push(e), this.update(), i.a.toast("恭喜，领取成功<br>限当日有效", 3e3)
            },
            removeCoupon: function(e) {
                if (!e) {
                    if (!(this.couponIndex > -1 && this.couponSetting && this.couponSetting.list)) return;
                    e = this.couponSetting.list[this.couponIndex]
                }
                for (var t = 0; t < this.currentCoupon.length; t++)
                    if (this.isSameCoupon(e, this.currentCoupon[t])) {
                        this.currentCoupon.splice(t, 1), this.update();
                        break
                    }
            },
            couponExist: function(e) {
                for (var t = 0; t < this.currentCoupon.length; t++)
                    if (this.isSameCoupon(e, this.currentCoupon[t])) return !0;
                return !1
            },
            update: function() {
                window.EC.isTogether || r.a.updatePrice(), this.updateCookie()
            },
            updateCookie: function() {
                o.a.setCookie(this.getKey(), {
                    time: Date.now(),
                    list: this.currentCoupon || []
                }, 1);
                try {
                    var e = s.a.get(),
                        t = [];
                    for (var n in e) n.indexOf("coupon_") > -1 && t.push({
                        key: n,
                        value: JSON.parse(e[n])
                    });
                    if (t.length > 10) {
                        t.sort(function(e, t) {
                            return t.value.time - e.value.time
                        });
                        for (var r = t.length - 1; r >= 10; r--) {
                            var i = t[r];
                            o.a.removeCookie(i.key)
                        }
                    }
                } catch (e) {}
            },
            isSameCoupon: function(e, t) {
                return e.full == t.full && e.minus == t.minus
            },
            getCouponIndex: function() {
                return this.couponIndex
            },
            updateCouponIndex: function(e) {
                if (this.couponSetting && this.couponSetting.list)
                    for (var t = 0; t < this.couponSetting.list.length; t++)
                        if (this.isSameCoupon(e, this.couponSetting.list[t])) return void(this.couponIndex = t);
                this.couponIndex = -1
            }
        }
    },
    887: function(e, t, n) {
        "use strict";
        var o = n(168),
            r = n(919),
            i = n(108);
        t.a = function() {
            function e(e) {
                var t = document.querySelector('[for="' + l.id + '"]'),
                    n = !0,
                    r = "";
                return t.innerText = "", l.value ? o.a.chinese.test(l.value) || (r = "【姓名】只能输入中文", t.innerText = "姓名只能输入中文", n = !1) : (r = "请完善【姓名】信息", t.innerText = "请输入姓名", n = !1), !n && e && i.a.alert({
                    message: r
                }), n
            }

            function t(e) {
                if (m) {
                    var t = document.querySelector('[for="' + m.id + '"]'),
                        n = !0,
                        r = "";
                    return t.innerText = "", m.value ? o.a.id_number.test(m.value) || (r = "【身份证】格式错误", t.innerText = "身份证格式错误", n = !1) : (r = "请完善【身份证】信息", t.innerText = "请输入身份证", n = !1), !n && e && i.a.alert({
                        message: r
                    }), n
                }
                return !0
            }

            function n(e) {
                var t = document.querySelector('[for="' + d.id + '"]'),
                    n = !0,
                    r = "";
                return t.innerText = "", d.value ? o.a.mobile.test(d.value) || o.a.phone.test(d.value) || (r = "【手机】格式错误", t.innerText = "手机号码格式错误", n = !1) : (r = "请完善【手机】信息", t.innerText = "请输入手机号码", n = !1), !n && e && i.a.alert({
                    message: r
                }), n
            }

            function a(e) {
                return r.a.validate(e)
            }

            function s(e) {
                var t = document.querySelector('[for="' + p.id + '"]'),
                    n = !0,
                    o = "";
                return t.innerText = "", p.value || (o = "请完善【地址】信息", t.innerText = "请输入详细地址", n = !1), !n && e && i.a.alert({
                    message: o
                }), n
            }

            function u(o) {
                return e(o) && t(o) && n(o) && a(o) && s(o)
            }

            function c() {
                l.value = "", d.value = "", f.value = "", p.value = "", m && (m.value = ""), r.a.clear()
            }
            var l = document.querySelector("#name"),
                d = document.querySelector("#phone"),
                p = document.querySelector("#addressdetail"),
                f = document.querySelector("#message"),
                m = document.querySelector("#idNumber"),
                h = function() {
                    r.a.init(), ["blur"].forEach(function(o) {
                        l.addEventListener(o, function() {
                            e()
                        }), m && m.addEventListener(o, function() {
                            t()
                        }), d.addEventListener(o, function() {
                            n()
                        }), p.addEventListener(o, function() {
                            s()
                        })
                    })
                };
            return {
                validate: u,
                clear: c,
                getName: function() {
                    return l.value
                },
                validatePhone: n,
                getPhone: function() {
                    return d.value
                },
                getMessage: function() {
                    return f.value
                },
                getIdNumber: function() {
                    return m ? m.value : ""
                },
                getAddressDetail: function() {
                    return p.value
                },
                getProvince: function() {
                    return r.a.getProvince()
                },
                getCity: function() {
                    return r.a.getCity()
                },
                getArea: function() {
                    return r.a.getArea()
                },
                init: h
            }
        }()
    },
    888: function(e, t, n) {
        "use strict";
        var o = n(62),
            r = n(570);
        t.a = {
            packageAmount: document.querySelector("#package-amount"),
            packageMinus: document.querySelector('#package-spinner [data-type="left"]'),
            packagePlus: document.querySelector('#package-spinner [data-type="right"]'),
            count: 1,
            MIN_COUNT: 1,
            MAX_COUNT: 10,
            setCount: function(e) {
                this.count = isNaN(e) ? this.MIN_COUNT : Math.min(this.MAX_COUNT, Math.max(this.MIN_COUNT, e)), this.setUI()
            },
            getCount: function() {
                return this.count
            },
            setUI: function() {
                this.packageAmount && this.packagePlus && this.packageMinus && (this.packageAmount.innerText = this.count, this.count == this.MIN_COUNT && o.a.addClass(this.packageMinus, "disabled"), this.count > this.MIN_COUNT && o.a.removeClass(this.packageMinus, "disabled"), this.count == this.MAX_COUNT && o.a.addClass(this.packagePlus, "disabled"), this.count < this.MAX_COUNT && o.a.removeClass(this.packagePlus, "disabled"))
            },
            init: function() {
                this.setCount(this.MIN_COUNT), o.a.on(this.packageMinus, "click", function() {
                    if (this.getCount() == this.MIN_COUNT) return !1;
                    this.setCount(this.getCount() - 1), r.a.updatePrice()
                }.bind(this)), o.a.on(this.packagePlus, "click", function() {
                    if (this.getCount() == this.MAX_COUNT) return !1;
                    this.setCount(this.getCount() + 1), r.a.updatePrice()
                }.bind(this))
            },
            clear: function() {
                this.setCount(this.MIN_COUNT)
            }
        }
    },
    894: function(e, t, n) {
        "use strict";
        var o = n(62);
        ! function() {
            ({
                init: function() {
                    if (window.performance && window.performance.timing) {
                        var e = this,
                            t = 0,
                            n = 0;
                        window.addEventListener("load", function o() {
                            0 == t && (n = e.getImgErrorNum());
                            var r = e.getData();
                            r.onload > 0 ? (r.imgFirstErrorNum = n, r.imgSecondErrorNum = r.imgErrorNum, delete r.imgErrorNum, e.send(r)) : setTimeout(function() {
                                t++, o()
                            }, 200)
                        })
                    }
                },
                getImgErrorNum: function() {
                    for (var e = 0, t = document.querySelectorAll(".preview-phone img"), n = 0; n < t.length; n++) {
                        var o = t[n],
                            r = o.getAttribute("src");
                        r && this.inDomain(r) && void 0 != o.naturalWidth && o.complete && 0 == o.naturalWidth && e++
                    }
                    return e
                },
                inDomain: function(e) {
                    return /p[0-9]?\.qpic\.cn/i.test(e) || /p\.fyeds[0-4]\.com/i.test(e)
                },
                reportToMaya: function(e, t, n) {
                    "undefined" != typeof maya && maya.report(e, t, 0, 4, n)
                },
                getData: function() {
                    var e = this,
                        t = window.performance.timing,
                        n = {
                            blank: t.domLoading - t.fetchStart,
                            domready: t.domContentLoadedEventEnd - t.fetchStart,
                            onload: t.loadEventEnd - t.fetchStart,
                            imgNumForLoadTime: 0,
                            imgNumForError: 0,
                            imgsLoadTime: 0,
                            imgErrorNum: 0,
                            firstScreen: 0,
                            error564: 0,
                            error503: 0,
                            errorStatusCode: 0
                        },
                        o = document.querySelector(".mo");
                    if (o = o ? o.getAttribute("src") : null, window.performance.getEntries)
                        for (var r = window.performance.getEntries() || [], i = 0; i < r.length; i++) {
                            var a = r[i];
                            if ("img" == a.initiatorType) {
                                var s = a.name;
                                s && this.inDomain(s) && (n.imgNumForLoadTime++, n.imgsLoadTime += parseInt(a.duration || 0), o && s.indexOf(o) > -1 && (n.firstScreen = parseInt(a.duration || 0)), a.x5HttpStatusCode && 564 == a.x5HttpStatusCode && n.error564++, a.x5HttpStatusCode && 503 == a.x5HttpStatusCode && n.error503++, a.x5HttpStatusCode && 200 != a.x5HttpStatusCode && n.errorStatusCode++)
                            }
                        }
                    for (var u = this, c = document.querySelectorAll(".preview-phone img"), l = 0; l < c.length; l++) {
                        var d;
                        ! function(t) {
                            d = c[t];
                            var o = d.getAttribute("src");
                            o && e.inDomain(o) && (n.imgNumForError++, void 0 != d.naturalWidth && d.complete && 0 == d.naturalWidth && (! function(e) {
                                e.onerror = function() {
                                    u.reportToMaya(e.src + "加载失败@" + encodeURIComponent(window.location.href), e.src, 4)
                                }, e.src = o.replace(/p[0-9]?\.qpic\.cn/i, "p.qpic.cn")
                            }(d), e.reportToMaya(o + "加载失败@" + encodeURIComponent(window.location.href), o, 3), n.imgErrorNum++))
                        }(l)
                    }
                    return n
                },
                trueSend: function(e) {
                    var t = "//" + window.EC.statHost + "/stat/report/front",
                        n = ["citoken=" + o.a.getCiToken(), "timestamp=" + EC.timestamp];
                    for (var r in e) n.push(r + "=" + encodeURIComponent(e[r]));
                    o.a.reportByImg(t + "?" + n.join("&"))
                },
                send: function(e) {
                    if (e.onload > 0 && e.onload < 3e4 && e.imgNumForLoadTime > 0 && e.imgsLoadTime > 0 && e.imgsLoadTime < 15e5 && e.imgNumForError > 0 && e.firstScreen > 0 && e.firstScreen < 12e4) {
                        var t = this;
                        o.a.isCiTokenOutOfTime() ? o.a.getCiTokenFromServer(function() {
                            t.trueSend(e)
                        }, "mo") : this.trueSend(e)
                    }
                }
            }).init()
        }()
    },
    895: function(e, t, n) {
        "use strict";
        var o = n(62);
        ! function() {
            var e = document.querySelector(".swiper-container");
            document.querySelector(".first-image .swiper-pagination");
            e && o.a.loadScript(o.a.getStaticDomain() + "/swiper.min.js", function() {
                if (window.Swiper) {
                    var t = window.EC.indexPicSpeed || 0,
                        n = e.querySelector("#videoIndexPic"),
                        o = -1;
                    n && (o = parseInt(n.getAttribute("data-sort")));
                    var r = document.createEvent("Event");
                    r.initEvent("scrollToVideo", !0, !0);
                    var i = new window.Swiper(e, {
                        autoplay: t,
                        loop: !1,
                        setWrapperSize: !0,
                        pagination: ".swiper-pagination",
                        paginationClickable: !0,
                        autoplayDisableOnInteraction: !1,
                        onSlideChangeEnd: function(t) {
                            t.activeIndex == o && e.dispatchEvent(r)
                        }
                    });
                    0 == o && e.dispatchEvent(r), t && (0 == o && i.stopAutoplay(), e.addEventListener("videoPlay", function() {
                        i.stopAutoplay()
                    }, !1), e.addEventListener("videoStop", function() {
                        i.startAutoplay()
                    }, !1))
                }
            })
        }()
    },
    896: function(e, t, n) {
        "use strict";
        var o = n(154),
            r = n(915),
            i = n(62),
            a = n(570),
            s = n(887),
            u = n(917),
            c = n(888),
            l = n(108),
            d = n(920),
            p = n(918),
            f = n(886),
            m = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o])
                }
                return e
            };
        ! function(e) {
            function t() {
                s.a.clear(), c.a.clear(), a.a.clear(), a.a.updatePrice(), d.a.close()
            }
            var n = document.querySelector("body"),
                h = {
                    slide: 1,
                    order: 2,
                    phone: 3,
                    msg: 4,
                    consultation: 7,
                    purchase_right_now: 6,
                    two_jump: 8
                };
            if ("" != e.EC.coupon && f.a.init(), !i.a.hasFirstImage()) {
                var g = document.querySelector(".pic-module");
                g && i.a.insertAfter(document.querySelector("#marketingModules"), g)
            }
            if (!e.EC.isTogether) {
                var v = function() {
                    var n = a.a.getPackageInfo(),
                        p = {
                            r_id: e.EC.rId,
                            g_id: e.EC.gId,
                            g_name: e.EC.gName,
                            package_count: c.a.getCount(),
                            package_price: parseFloat(a.a.getPackagePrice()).toFixed(2),
                            user_name: s.a.getName(),
                            user_phone: s.a.getPhone(),
                            user_address: s.a.getAddressDetail(),
                            user_message: s.a.getMessage(),
                            user_province: s.a.getProvince(),
                            user_city: s.a.getCity(),
                            user_area: s.a.getArea(),
                            user_id_number: s.a.getIdNumber(),
                            pay: a.a.getPay(),
                            pay_type: 1,
                            package_info: n
                        };
                    f.a.getCouponIndex() > -1 && (p.coupon_id = f.a.getCouponId(), p.coupon_index = f.a.getCouponIndex());
                    var g = i.a.getUrlParam("together_id");
                    g && (p.together_id = g), u.a.save(), l.a.loading();
                    var v = {
                            url: "/order/submit",
                            method: "post",
                            data: {
                                info: p,
                                verify_code: d.a.getCode(),
                                qz_gdt: i.a.getUrlParam("qz_gdt"),
                                gdt_vid: i.a.getUrlParam("gdt_vid"),
                                version_g_id: e.EC.version_g_id
                            }
                        },
                        y = i.a.getUrlParam("commit_source");
                    y && "" != i.a.trim(y) && (v.data.commit_source = y), i.a.ajax(m({}, v, {
                        success: function(n) {
                            l.a.hideLoading();
                            var s = n.code;
                            if (s == o.a.success) return r.a.clickSend({
                                click_id: h.order,
                                pay: 100 * a.a.getPay()
                            }), f.a.getCouponIndex() > -1 && f.a.removeCoupon(), t(), l.a.showOrderSubmitSuccessDialog({
                                message: "您的订单已提交成功！"
                            });
                            if (s == o.a.needToRefresh) return l.a.alert({
                                message: n.message,
                                onOk: function() {
                                    e.location.reload(!0)
                                }
                            }), !1;
                            if (s == o.a.smsVerifyError) return d.a.show(o.a.smsVerifyError, n.message), !1;
                            if (s == o.a.couponError) f.a.removeCoupon();
                            else {
                                if (s == o.a.needSmsVerify) return d.a.show(o.a.needSmsVerify), !1;
                                i.a.reportJsError("ajax error:" + n.message)
                            }
                            l.a.toast(n.message)
                        },
                        error: function(e) {
                            l.a.hideLoading(), l.a.toast(e.msg || "请求发生错误，请重试", 3e3), d.a.close()
                        },
                        tryTimes: 2
                    }))
                };
                e.addEventListener("load", function() {
                    i.a.runCiTokenTimer()
                }), s.a.init(), a.a.init(), c.a.init(), d.a.init(v), p.a.init();
                var y = document.querySelector(".good-hot-wrapper");
                y && i.a.removeClass(y, "hide"), i.a.on(document.querySelector("#submit-button"), "click", function() {
                    return EC.isPublish ? !!a.a.validate() && (s.a.validate(!0) ? void(e.EC.isSMSVerifyOpen ? d.a.show() : v()) : (i.a.scrollToElement("#name"), !1)) : l.a.toast("页面未发布，不能提交订单")
                }), i.a.on(document.querySelector("#contact_tel"), "click", function() {
                    r.a.clickSend(h.phone)
                }), i.a.on(document.querySelector("#contact_msg"), "click", function() {
                    r.a.clickSend(h.msg)
                }), i.a.on(document.querySelector("#consultation"), "click", function() {
                    r.a.clickSend(h.consultation)
                }), i.a.on(document.querySelector("#contact-no"), "click", function() {
                    r.a.clickSend(h.phone)
                }), e.addEventListener("scroll", function() {
                    var e = document.getElementById("btn-list"),
                        t = document.getElementById("ec-form-wrapper");
                    t && (i.a.isScrolledIntoView(t) ? i.a.hasClass(e, "fade-out") || i.a.addClass(e, "fade-out") : i.a.removeClass(e, "fade-out"))
                })
            }
            var w = function e(t) {
                t.preventDefault(), r.a.clickSend(h.slide), n.removeEventListener("touchmove", e)
            };
            n.addEventListener("touchmove", w), i.a.on(document.querySelectorAll('[data-type="purchase-btn"]'), "click", function() {
                r.a.clickSend(h.purchase_right_now)
            }), i.a.on(document.querySelectorAll(".together-link"), "click", function() {
                r.a.clickSend(h.two_jump)
            }), i.a.isGrey() && i.a.addClass(document.querySelector("#fyBrand"), "fygrey");
            var C = i.a.getUrlParam("pretoken"),
                S = document.querySelector("#previewTip");
            C && C.indexOf("gdt.audit") > -1 ? i.a.removeClass(document.querySelector("#auditModule"), "hide") : S && i.a.removeClass(S, "hide"), e.EC.isTogether && e.addEventListener("load", function() {
                var e = new XMLHttpRequest;
                e.open("GET", "/common/region.min.js?v=20171129", !0), e.send()
            })
        }(window)
    },
    897: function(e, t, n) {
        "use strict";
        var o = n(62);
        ! function() {
            function e() {
                var e = !1;
                o.a.forEach(t, function(t) {
                    var a = t.getAttribute("id"),
                        s = t.getAttribute("data-vid"),
                        u = t.getAttribute("data-width"),
                        c = t.getAttribute("data-height");
                    if (s) {
                        var l = function(e) {
                                e ? (o.a.addClass(n.querySelectorAll(".swiper-slide"), "remove-transform"), o.a.addClass(n.querySelectorAll(".swiper-wrapper"), "remove-transform")) : (o.a.removeClass(n.querySelectorAll(".swiper-slide"), "remove-transform"), o.a.removeClass(n.querySelectorAll(".swiper-wrapper"), "remove-transform"))
                            },
                            d = !1;
                        d = "videoIndexPic" === a ? 0 == parseInt(r.getAttribute("data-sort")) : !r && o.a.isWIFI();
                        var p = Math.round(i * c / u),
                            f = new Txplayer({
                                autoplay: !e && d,
                                containerId: a,
                                muted: !0,
                                vid: s,
                                poster: t.getAttribute("data-poster"),
                                width: i,
                                height: p
                            });
                        t.style.height = p + "px", f.on("playStateChange", function(e) {
                            if (-1 != e && 0 != e) {
                                var t = document.querySelector("#" + a + " .txp_right_controls");
                                if (!document.querySelector("#button_" + a) && t) {
                                    var n = document.createElement("div");
                                    n.setAttribute("id", "button_" + a), o.a.addClass(n, "mute"), n.innerText = " ", t.appendChild(n), n.onclick = function() {
                                        f.isMute() ? (f.unMute(), o.a.removeClass(n, "mute"), o.a.addClass(n, "unmute")) : (f.mute(), o.a.removeClass(n, "unmute"), o.a.addClass(n, "mute"))
                                    }
                                }
                            }
                        }), d && (e = !0), "videoIndexPic" == a && n && function(e, t) {
                            var o = document.createEvent("Event");
                            o.initEvent("videoPlay", !0, !0);
                            var r = document.createEvent("Event");
                            r.initEvent("videoStop", !0, !0), n.addEventListener("scrollToVideo", function() {
                                if (e.play) {
                                    -1 === e.getPlayerState() && e.play()
                                } else e.on("ready", function() {
                                    -1 === e.getPlayerState() && e.play()
                                })
                            }, !1), e.on("playStateChange", function(e) {
                                -1 == e || 0 == e ? n.dispatchEvent(r) : n.dispatchEvent(o)
                            }), e.on("windowFullscreenChange", function(e) {
                                l(e)
                            }), e.on("browserFullscreenChange", function(e) {
                                l(e)
                            })
                        }(f)
                    }
                })
            }
            var t = document.querySelectorAll("div[data-vid]"),
                n = document.querySelector(".swiper-container"),
                r = document.querySelector("#videoIndexPic"),
                i = EC.isMobile ? o.a.getWindowSize().width : 640;
            t.length && o.a.loadScript("//vm.gtimg.cn/tencentvideo/txp/js/txplayer.js", function() {
                Txplayer && e()
            })
        }()
    },
    898: function(e, t, n) {
        "use strict";
        var o = n(62),
            r = n(154),
            i = n(379);
        ! function() {
            function e(e) {
                if (o.a.isString(e)) {
                    var t = "//" + window.EC.statHost + "/stat/report/networktype2mo",
                        n = ["citoken=" + o.a.getCiToken(), "timestamp=" + EC.timestamp, "networktype_str=" + e, "networktype_int=" + ["2g", "3g", "4g", "wifi"].indexOf(e.toLowerCase())];
                    o.a.reportByImg(t + "?" + n.join("&"))
                }
            }

            function t(e, t) {
                var n = window.EC.isTogether ? " " : window.EC.goodsType.length > 14 ? window.EC.goodsType.substr(0, 11) + "..." : window.EC.goodsType,
                    r = window.EC.title.length > 20 ? window.EC.title.substr(0, 17) + "..." : window.EC.title,
                    i = window.EC.mainPic,
                    a = "true" == o.a.getUrlParam("newwxapi");
                e.onMenuShareTimeline && e.onMenuShareQZone && !a ? (window.wx.onMenuShareTimeline({
                    title: n,
                    link: t,
                    imgUrl: i,
                    success: function() {}
                }), window.wx.onMenuShareQZone({
                    title: n,
                    desc: r,
                    link: t,
                    imgUrl: i,
                    success: function() {}
                })) : e.updateTimelineShareData && window.wx.updateTimelineShareData({
                    title: n,
                    link: t,
                    imgUrl: i
                }, function(e) {}), e.onMenuShareAppMessage && e.onMenuShareQQ && !a ? (window.wx.onMenuShareAppMessage({
                    title: n,
                    desc: r,
                    link: t,
                    imgUrl: i,
                    success: function() {}
                }), window.wx.onMenuShareQQ({
                    title: n,
                    desc: r,
                    link: t,
                    imgUrl: i,
                    success: function() {}
                })) : e.updateAppMessageShareData && window.wx.updateAppMessageShareData({
                    title: n,
                    desc: r,
                    link: t,
                    imgUrl: i
                }, function(e) {})
            }

            function n(n) {
                var r = ["onMenuShareTimeline", "onMenuShareAppMessage", "onMenuShareQQ", "onMenuShareQZone", "updateTimelineShareData", "updateAppMessageShareData", "getNetworkType"];
                window.wx.config({
                    debug: "true" == o.a.getUrlParam("openwxdebug"),
                    appId: n.data.appId,
                    timestamp: n.data.timestamp,
                    nonceStr: n.data.nonceStr,
                    signature: n.data.signature,
                    jsApiList: r
                }), window.wx.ready(function() {
                    window.wx.checkJsApi({
                        jsApiList: r,
                        success: function(o) {
                            var r = o.checkResult;
                            r.getNetworkType && window.wx.getNetworkType({
                                success: function(t) {
                                    e(t.networkType)
                                }
                            }), t(r, n.data.url)
                        }
                    })
                })
            }
            o.a.isWX() && !i.a.isMpShareClose() && o.a.loadScript("//res.wx.qq.com/open/js/jweixin-1.4.0.js", function() {
                window.wx && o.a.ajax({
                    url: "/info/wxjsticket?url=" + window.encodeURIComponent(window.location.href),
                    success: function(e) {
                        e.code == r.a.success && n(e)
                    }
                })
            })
        }()
    },
    900: function(e, t) {},
    914: function(e, t, n) {
        "use strict";
        var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        };
        t.a = function() {
            function e() {
                this._events = {}
            }
            return e.prototype = {
                call: function(e) {
                    if (this._events[e]) {
                        var t = 0,
                            n = this._events[e].length;
                        if (0 != n)
                            for (; t < n; ++t) this._events[e][t].apply(this, arguments[1])
                    }
                },
                listen: function(e, t) {
                    if (void 0 == t && "object" == o(arguments[0]))
                        for (var n in e) arguments.callee.call(this, n, e[n]);
                    this._events[e] || (this._events[e] = []), this._events[e].push(t)
                },
                off: function(e, t) {
                    if (this._events[e]) {
                        var n = this._events[e].indexOf(t);
                        n > -1 && this._events[e].splice(n, 1)
                    }
                }
            }, e
        }()
    },
    915: function(e, t, n) {
        "use strict";
        var o = n(62),
            r = {
                init: function() {
                    if (window.performance && window.performance.timing) {
                        var e = this;
                        "onunload" in window ? window.addEventListener("unload", function() {
                            e.accessTime()
                        }) : "onpagehide" in window && window.addEventListener("pagehide", function() {
                            e.accessTime()
                        })
                    }
                },
                reportViewTimeToMo: function(e) {
                    var t = "//" + window.EC.statHost + "/stat/report/viewtime",
                        n = ["citoken=" + o.a.getCiToken(), "timestamp=" + window.EC.timestamp];
                    for (var r in e) n.push(r + "=" + encodeURIComponent(e[r]));
                    o.a.reportByImg(t + "?" + n.join("&"))
                },
                trueSend: function(e, t) {
                    t = t || {};
                    var n = ["r_id=" + window.EC.rId, "g_id=" + window.EC.gId, "u_id=" + window.EC.account_id, "citoken=" + o.a.getCiToken(), "timestamp=" + window.EC.timestamp, "goods_type_id=" + (window.EC.goodsTypeId || ""), "ua=" + encodeURIComponent(window.navigator.userAgent), "os=" + o.a.getOS(), "page_url=" + encodeURIComponent(window.location.href), "referer=" + encodeURIComponent(document.referrer)];
                    o.a.getUrlParam("qz_gdt") && n.push("qz_gdt=" + o.a.getUrlParam("qz_gdt")), o.a.getUrlParam("gdt_vid") && n.push("gdt_vid=" + o.a.getUrlParam("gdt_vid")), o.a.getUrlParam("soid") && n.push("soid=" + o.a.getUrlParam("soid")), o.a.getUrlParam("ecfrom") && n.push("ecfrom=" + o.a.getUrlParam("ecfrom"));
                    for (var r in t) n.push(r + "=" + encodeURIComponent(t[r]));
                    t.view_time && this.reportViewTimeToMo({
                        viewtime: t.view_time
                    }), o.a.reportByImg("//" + window.EC.statHost + "/stat/page" + e + "?" + n.join("&"))
                },
                send: function(e, t) {
                    if (!(!EC.isPublish || EC.fromAdmin || window.location.host.indexOf("ec.fypage.cn") > -1)) {
                        var n = this;
                        o.a.isCiTokenOutOfTime() ? o.a.getCiTokenFromServer(function() {
                            n.trueSend(e, t)
                        }, "report") : this.trueSend(e, t)
                    }
                },
                clickSend: function(e) {
                    /\d+/.test(e) && (e = {
                        click_id: e
                    }), this.send("/click", e)
                },
                accessTime: function() {
                    var e = window.performance.timing,
                        t = e.domContentLoadedEventEnd - e.fetchStart,
                        n = +new Date - e.domInteractive;
                    t > 0 && n > 0 && this.send("/stay", {
                        view_time: n,
                        load_time: t
                    })
                }
            };
        r.init(), t.a = r
    },
    916: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(900);
        n.n(o), n(896), n(895), n(897), n(894), n(898)
    },
    917: function(e, t, n) {
        "use strict";
        var o = n(62);
        t.a = function() {
            var e = document.querySelector("#cookiecheck");
            if (e) {
                var t = o.a.getCookie("isChecked");
                if (void 0 == t && o.a.setCookie("isChecked", e.checked ? 1 : 0, 365), e.addEventListener("change", function() {
                        o.a.setCookie("isChecked", this.checked ? 1 : 0, 365)
                    }, !1), e.checked = void 0 == t || parseInt(t), e.checked) {
                    var n = o.a.getCookie("form", "json");
                    n && (document.querySelector("#name").value = n.name, document.querySelector("#phone").value = n.phone, document.querySelector("#addressdetail").value = n.addressdetail)
                }
            }
            return {
                save: function() {
                    o.a.setCookie("form", {
                        name: document.querySelector("#name").value,
                        phone: document.querySelector("#phone").value,
                        province: document.querySelector("#province").value,
                        city: document.querySelector("#city").value,
                        area: document.querySelector("#area").value,
                        addressdetail: document.querySelector("#addressdetail").value
                    }, 365)
                }
            }
        }()
    },
    918: function(e, t, n) {
        "use strict";
        var o = n(62),
            r = n(379);
        t.a = {
            list: ["长沙王**购买了该商品，3秒前", "天津李**购买了该商品，4秒前", "北京郭**购买了该商品，5秒前", "西宁马**购买了该商品，7秒前", "广州颜**购买了该商品，12秒前", "成都冼**购买了该商品，23秒前", "无锡王**购买了该商品，34秒前", "温州马**购买了该商品，45秒前", "拉萨阿**购买了该商品，56秒前", "深圳唐**购买了该商品，59秒前"],
            headLength: 20,
            totalLoop: 0,
            top: 1e6,
            loopInterval: 4e3,
            hasFirstImage: !1,
            wrapper: document.querySelector(".marquee-wrapper"),
            contentLi: document.querySelector("#marqueeContainer li"),
            header: document.querySelector("#marqueeContainer li div"),
            text: document.querySelector("#marqueeContainer li span"),
            init: function() {
                this.wrapper && this.contentLi && this.header && this.text && (this.hasFirstImage = o.a.hasFirstImage(), this.load(function() {
                    if (this.list && this.list.length) {
                        if (!this.hasFirstImage) {
                            document.querySelector(".pic-module") || (this.wrapper.style["margin-top"] = "0px")
                        }
                        this.updateUI(), o.a.removeClass(this.wrapper, "hide"), this.run(Date.now())
                    }
                }.bind(this)), window.addEventListener("scroll", function() {
                    this.fixToTop()
                }.bind(this)))
            },
            fixToTop: function() {
                (window.pageYOffset || window.scrollY) > this.top ? o.a.addClass(this.wrapper, "fix") : (o.a.removeClass(this.wrapper, "fix"), this.top = this.wrapper.offsetTop)
            },
            load: function(e) {
                var t = this;
                r.a.isMarqueeClose() || (window.EC.isPublish ? o.a.ajax({
                    url: "/order/marquee",
                    success: function(n) {
                        t.list = n.data || [];
                        for (var o = 0; o < t.list.length; o++) t.list[o].length > 18 && (t.list[o] = t.list[o].substr(0, 18) + "...");
                        e && e()
                    },
                    tryTimes: 2
                }) : e && e())
            },
            run: function(e) {
                var t = this;
                window.requestAnimationFrame ? window.requestAnimationFrame(function() {
                    var n = Date.now(),
                        o = n - e;
                    o <= .15 * t.loopInterval ? (t.contentLi.style.opacity = o / (.15 * t.loopInterval), t.run(e)) : o >= .6 * t.loopInterval && o <= .8 * t.loopInterval ? (t.contentLi.style.opacity = 1 - (o - .6 * t.loopInterval) / (.2 * t.loopInterval), t.run(e)) : o >= t.loopInterval ? (t.totalLoop++, t.contentLi.style.opacity = 0, t.updateUI(), t.run(n)) : t.run(e)
                }) : (this.contentLi.style.opacity = 1, window.setInterval(function() {
                    t.totalLoop++, t.updateUI()
                }, t.loopInterval))
            },
            updateUI: function() {
                var e = o.a.randomRange(1, 10);
                e = 52 * -(e - 1) - 4, this.header.style.backgroundPosition = e + "px -4px", this.text.innerText = this.list[this.totalLoop % this.list.length]
            }
        }
    },
    919: function(e, t, n) {
        "use strict";
        var o = n(62),
            r = n(108),
            i = n(379);
        t.a = function() {
            function e(e) {
                var t = n[e];
                t && t.children && (d(s, t.children, "请选择城市"), d(u, [], "请选择地区"), o.a.removeClass(s, "hide"))
            }

            function t(e, t) {
                var r = n[e];
                if (r) {
                    var i = r.children[t];
                    i && i.children ? (d(u, i.children, "请选择地区"), o.a.removeClass(u, "hide")) : o.a.addClass(u, "hide")
                }
            }
            var n = window.RegionData,
                a = document.querySelector("#province"),
                s = document.querySelector("#city"),
                u = document.querySelector("#area"),
                c = function() {
                    l(), a.addEventListener("change", function(t) {
                        p(), e(t.target.value)
                    }), s.addEventListener("change", function(e) {
                        f(), t(a.value, e.target.value)
                    }), u.addEventListener("change", function() {
                        m()
                    });
                    var r = o.a.getCookie("form", "json");
                    if (r && document.querySelector("#cookiecheck").checked) {
                        var c = parseInt(r.province);
                        if (!isNaN(c) && n[c]) {
                            a.value = c, e(c);
                            var d = parseInt(r.city);
                            isNaN(d) || n[c].children[d] && (s.value = d, t(c, d), u.value = r.area)
                        }
                    } else i.a.isIpLocationClose() || o.a.ajax({
                        url: "/info/ip",
                        success: function(r) {
                            if (1 == r.code && r.data)
                                for (var i = -1, c = -1, l = (r.data.province_name || "").replace(/(市|省|自治区|特别行政区|维吾尔|回族|壮族)/gi, ""), d = (r.data.city_name || "").replace(/(市|地区|区|自治州)/gi, ""), p = (r.data.town_name || "").replace(/(区|县)/gi, ""), f = 0; f < n.length; f++)
                                    if ("" != o.a.trim(l) && n[f].label.indexOf(l) > -1) {
                                        i = n[f].value, a.value = i, e(i);
                                        var m = n[f].children;
                                        if (m)
                                            for (var h = 0; h < m.length; h++)
                                                if ("" != o.a.trim(d) && m[h].label.indexOf(d) > -1) {
                                                    c = h, s.value = c, t(i, c);
                                                    var g = m[h].children;
                                                    if (g)
                                                        for (var v = 0; v < g.length; v++) "" != o.a.trim(p) && g[v].label.indexOf(p) > -1 && (u.value = v);
                                                    return
                                                } return
                                    }
                        },
                        tryTimes: 0
                    })
                },
                l = function() {
                    d(a, n, "请选择省份"), d(s, [], "请选择城市"), d(u, [], "请选择地区")
                },
                d = function(e, t, n) {
                    var o = document.createDocumentFragment(),
                        r = document.createElement("option");
                    r.value = -1, r.innerHTML = n, o.appendChild(r), (t || []).forEach(function(e, t) {
                        r = document.createElement("option"), r.value = t, r.innerHTML = e.label, o.appendChild(r)
                    }), e && (e.innerHTML = "", e.appendChild(o))
                },
                p = function(e) {
                    var t = document.querySelector('[for="' + u.id + '"]');
                    return null === g() ? (t.innerText = "请选择省份", e && r.a.alert({
                        message: "请完善【地区】省份信息"
                    }), !1) : (t.innerText = "", !0)
                },
                f = function(e) {
                    var t = document.querySelector('[for="' + u.id + '"]');
                    return null === v() ? (t.innerText = "请选择城市", e && r.a.alert({
                        message: "请完善【地区】城市信息"
                    }), !1) : (t.innerText = "", !0)
                },
                m = function(e) {
                    var t = document.querySelector('[for="' + u.id + '"]');
                    return null === y() ? (t.innerText = "请选择地区", e && r.a.alert({
                        message: "请完善【地区】地区信息"
                    }), !1) : (t.innerText = "", !0)
                },
                h = function(e) {
                    return p(e) && f(e) && m(e)
                },
                g = function() {
                    return n[a.value] ? n[a.value].label : null
                },
                v = function() {
                    if (!g()) return null;
                    if (n[a.value].children) return n[a.value].children[s.value] ? n[a.value].children[s.value].label : null
                },
                y = function() {
                    if (!g() || !v()) return null;
                    if (n[a.value].children[s.value].children) return n[a.value].children[s.value].children[u.value] ? n[a.value].children[s.value].children[u.value].label : null
                };
            return {
                validate: h,
                getProvince: g,
                getCity: v,
                getArea: y,
                clear: l,
                init: c
            }
        }()
    },
    920: function(e, t, n) {
        "use strict";
        var o = n(108),
            r = n(62),
            i = n(887),
            a = n(154);
        t.a = {
            intervalId: null,
            counter: 30,
            counting: !1,
            orderSubmitCallback: null,
            defaultText: "重新获取",
            verifyBtn: document.getElementById("verify-btn"),
            verifyInput: document.getElementById("sms-verify"),
            phoneNumberSpan: document.getElementById("phoneNumberSpan"),
            submitButton: document.getElementById("sms-submit-button"),
            smsVerifyCloseBtn: document.getElementById("smsVerifyCloseBtn"),
            validateTextEle: document.querySelector('[for="sms-verify"]'),
            dialog: document.getElementById("sms-dialog"),
            phoneNumber: "",
            init: function(e) {
                this.orderSubmitCallback = e, r.a.on(this.verifyBtn, "click", this.send.bind(this)), r.a.on(this.submitButton, "click", this.orderSubmit.bind(this)), r.a.on(this.smsVerifyCloseBtn, "click", function() {
                    r.a.addClass(this.dialog, "hide"), this.setCode("")
                }.bind(this))
            },
            getPhone: function() {
                return i.a.getPhone()
            },
            validate: function() {
                return "" == r.a.trim(this.verifyInput.value) ? (this.setError("请输入验证码"), !1) : (this.setError(""), !0)
            },
            show: function(e, t) {
                e == a.a.needSmsVerify ? (this.reset(), this.countDown()) : e == a.a.smsVerifyError ? this.setError(t) : this.phoneNumber != this.getPhone() ? (this.phoneNumber = this.getPhone(), this.reset(), this.send()) : this.counting ? this.setError("") : this.send(), r.a.removeClass(this.dialog, "hide")
            },
            close: function() {
                this.verifyInput && (this.reset(), r.a.addClass(this.dialog, "hide"))
            },
            reset: function() {
                this.intervalId && window.clearInterval(this.intervalId), this.intervalId = null, this.counter = 30, this.verifyBtn.innerText = this.defaultText, this.verifyInput.value = "", this.validateTextEle.innerText = "", this.counting = !1
            },
            orderSubmit: function() {
                this.validate() && this.orderSubmitCallback && this.orderSubmitCallback()
            },
            getCode: function() {
                return this.verifyInput ? this.verifyInput.value : ""
            },
            setCode: function(e) {
                this.verifyInput && (this.verifyInput.value = e)
            },
            setError: function(e) {
                this.validateTextEle.innerText = e
            },
            countDown: function() {
                var e = this;
                e.phoneNumberSpan.innerText = this.getPhone(), window.setTimeout(function() {
                    e.verifyBtn.innerText = e.defaultText + "(" + e.counter + ")", e.intervalId = window.setInterval(function() {
                        e.counter--, e.verifyBtn.innerText = e.defaultText + "(" + e.counter + ")", 0 == e.counter && e.reset()
                    }, 1e3)
                }, 200)
            },
            send: function() {
                var e = this,
                    t = this.getPhone();
                if (!t) return void o.a.toast("请填写电话号码", 3e3);
                if (!e.counting) {
                    var n = function(t) {
                        o.a.toast(t, 3e3), e.counting = !1
                    };
                    e.counting = !0, r.a.ajax({
                        url: "/order/codesend?phone=" + t,
                        success: function(t) {
                            t.code == a.a.success ? e.countDown() : n(t.message)
                        },
                        error: function() {
                            n("请求发生错误，请重试")
                        },
                        tryTimes: 2
                    })
                }
            }
        }
    }
});