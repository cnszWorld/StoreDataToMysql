<?php
include 'connection.php';
header('Content-Type: text/html; charset=utf-16');
header('Content-Type: text/html; charset=utf-8'); 
if(isset($_POST['totalprice'])){

        $totalprice=$_POST['totalprice'];
		$price=$_POST['price'];
		$qty=$_POST['count'];
		$color=$_POST['color'];
		$name=$_POST['name'];
		$phone=$_POST['phone'];
		$address=$_POST['address'];
		$province=$_POST['province'];
		$city=$_POST['city'];
		$region=$_POST['region'];
		$payment=$_POST['payment'];
		$message=$_POST['message'];
		$model=$_POST['model'];
		$commodity=$_POST['commodity'];
		$totalprice=$_POST['totalprice'];
		$name=$_POST['name'];
		$description='';
		


        $sql="INSERT INTO `orderItems`( `commodity`, `model`, `color`, `qty`, `total`) VALUES ('$commodity','".$model."','".$color."','".$qty."','".$totalprice."')";
           $db->query($sql);
           $last_id = $db->insert_id;
// die();
            if($last_id!=""){
              $sqlm="INSERT INTO `customer_message`( `orderID`, `message`) VALUES ('".$last_id."','".$message."')";
           $db->query($sqlm);

           $sqla="INSERT INTO `customerAddress`( `orderID`, `phoneNumber`, `province`, `city`, `region` , `street`) VALUES ('".$last_id."','".$phone."','".$province."','".$city."','".$region."','".$address."')";
           $db->query($sqla);
            	
            	$sqlc="INSERT INTO `customer`( `orderID`, `phoneNumber`, `customerName`) VALUES ('".$last_id."','".$phone."','".$name."')";
           $db->query($sqlc);

           $sqlcom="INSERT INTO `commodityCatalog`( `commodity`, `model`, `color`, `description`, `price`) VALUES ('".$commodity."','".$model."','".$color."','".$description."','".$price."')";
           $db->query($sqlcom);
echo '200';

            }

}else{
	echo '300';
}
?>