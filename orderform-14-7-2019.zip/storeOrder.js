
$(function() {
var count=1;
var price=0;
var totalprice=0;
var name='';
var phone='';
var province='';
var city='';
var region='';
var address='';
var payment='';
var color='';
var message='';
var model=''
var commodity='';



$(document).ready(function()
  {
     price = $(".price").attr('data-price');
  
    // alert(price);
     totalprice= parseFloat(count)*parseFloat(price);
     $('#couponTotalPrice').html(totalprice);
      model = $(".price").attr('data-package');
      // alert(model);
       commodity =$(".price").first('li').html();
      // alert(commodity);
  });

     $(".right").live("click", function() {
         count++;
         // alert(price);
          totalprice= parseFloat(count)*parseFloat(price);
         // alert(totalprice);
        $('#package-amount').html(count);
        $('#couponTotalPrice').html(totalprice);
        });

     $(".left").live("click", function() {

         count--;
        
         // alert(count);
         totalprice= totalprice - price;
         // alert(totalprice);
        $('#couponTotalPrice').html(totalprice);
        $('#package-amount').html(count);
        });

    $(".price").live("click", function() {
        $(".price").removeClass("active");  // remove active class from all
        $(this).addClass("active"); 
         price = $(this).closest('li').attr('data-price');
         // alert(price);

                // add active class to clicked element
        // $("#dijit_utm").load('index.html'); 
         model = $(this).attr('data-package');
          //alert(model);
            $(".color").removeClass("active"); 
          
             totalprice= parseFloat(count)*parseFloat(price);
             // alert('here');
             // alert(count);
              $('#couponTotalPrice').html(totalprice);
    });
$(".color").live("click", function() {
        $(".color").removeClass("active");  // remove active class from all
        $(this).addClass("active"); 
         color = $(this).closest('li').attr('data-value');
        // alert(color);
                // add active class to clicked element
        // $("#dijit_utm").load('index.html'); 
    });
    


     $(".left").live("change", function() {
         
         // alert('here');
       
        });

$(".payment").live("click", function() {
        $(".payment").removeClass("active");  // remove active class from all
        $(this).addClass("active"); 
         payment = $(this).closest('li').attr('data-value');
        // alert(payment);
      
                // add active class to clicked element
        // $("#dijit_utm").load('index.html'); 
    });

  $("#province").live("change", function() {

  province= $( "#province option:selected" ).text();
  // alert(province);

  });

  $("#city").live("change", function() {

  city= $( "#city option:selected" ).text();
  // alert(city);

  });

  $("#region").live("change", function() {

  region= $( "#region option:selected" ).text();
  // alert(region);

  });

     $("#addorder").submit(function(e){
    e.preventDefault();
   name= $('[name=name]').val();
   phone= $('[name=phone]').val();
   address= $('[name=address]').val();
   // province= $('[name=province]').val();
   // city= $('[name=city]').val();
   // region= $('[name=region]').val();
   message= $('[name=message]').val();

       $.ajax({
                    type: 'post',
                    url: 'addorder.php',
                    data: {totalprice:totalprice,count:count,color:color,name:name,phone:phone,address:address,province:province,city:city,region:region,payment:payment,message:message,model:model,price:price ,commodity:commodity },
                    success: function(data, status) {
                        //$('form')[0].reset();
                        // $("#feedback").text(response);
                        if (data=='200') {
                            
alert('Order Placed ');
window.location.reload(true);
                            
                            // $("#addshipper").load(location.href + " #addshipto");
                        } else
                           alert('Not success')
                    }
                });

});
});