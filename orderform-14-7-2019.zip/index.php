<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-16">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 
<title>此页面下单仅1折——高清航拍无人机</title>

<style inject="" type="text/css">@font-face{font-weight:400;font-style:normal;font-family:weui;src:url("/dist/weui.ttf") format("truetype")}[class*=" weui-icon-"],[class^=weui-icon-]{display:inline-block;vertical-align:middle;font-size:inherit}[class*=" weui-icon-"]:before,[class^=weui-icon-]:before{display:inline-block;margin-left:.2em;margin-right:.2em}.weui_mask{width:100%;height:100%;background:rgba(0,0,0,.6)}.weui-mask_transparent,.weui_mask{position:fixed;z-index:1000;top:0;left:0}.weui-mask_transparent{right:0;bottom:0}.weui-toast{position:fixed;z-index:9999999999;width:7.6em;min-height:7.6em;top:180px;left:50%;margin-left:-3.8em;background:hsla(0,0%,7%,.7);text-align:center;border-radius:4px;color:#fff}.weui-icon_toast{margin:22px 0 0;display:block}.weui-icon-success-no-circle:before{content:"\EA08"}.weui-icon-success-no-circle{font-size:23px;color:#09bb07}.weui-icon_toast.weui-icon-success-no-circle:before{color:#fff;font-size:55px}.weui-loading{width:20px;height:20px;display:inline-block;vertical-align:middle;background:transparent url("/images/loading.svg") no-repeat;background-size:100%}.weui-icon_toast.weui-loading{margin:22px 0 8px;width:38px;height:38px}.weui-toast__content{margin:0 0 15px}.weui_dialog{position:fixed;z-index:1002;width:85%;top:50%;left:50%;-webkit-transform:translate(-50%,-52%);transform:translate(-50%,-52%);background-color:#fafafc;text-align:center;border-radius:4px;overflow:hidden}.weui_dialog_hd{padding:1.2em 0 .5em}.weui_dialog_title{font-weight:400;font-size:17px}.weui_dialog_ft{position:relative;line-height:42px;margin-top:20px;font-size:17px;display:-webkit-box;display:-webkit-flex;display:flex}.weui_btn_dialog.primary{color:#cf2a4f}.weui_dialog_ft a{display:block;-webkit-box-flex:1;-webkit-flex:1;flex:1;color:#cf2a4f;text-decoration:none;-webkit-tap-highlight-color:rgba(0,0,0,0)}.order-success-dialog .weui_dialog_hd,.weui_dialog_alert .weui_dialog_hd{padding:0;line-height:48px}.order-success-dialog .weui_dialog_bd,.weui_dialog_alert .weui_dialog_bd{padding:4px 20px 18px;line-height:24px}.order-success-dialog .weui_dialog_ft,.weui_dialog_alert .weui_dialog_ft{line-height:48px;margin-top:0;border-top:1px solid #ddd}.order-success-dialog .order-submit-dialog-footer,.weui_dialog_alert .order-submit-dialog-footer{margin:0 20px 25px;border-radius:4px;line-height:42px}*{margin:0;padding:0;border:0;box-sizing:border-box;outline:0;-webkit-tap-highlight-color:transparent}body,html{font-family:Helvetica Neue,Helvetica,arial,STHeiTi,sans-serif;font-size:14px;color:#333}body{padding-bottom:constant(safe-area-inset-bottom);padding-bottom:env(safe-area-inset-bottom)}a,input,textarea{-webkit-tap-highlight-color:transparent}textarea{resize:none}a{text-decoration:none}.txp_next_poster{background-image:none!important}.fygrey:after,.fygrey:before{content:".";display:inline-block}.clear:after,.clear:before{display:table;clear:both;content:""}.preview-phone{position:relative}.preview-phone .mute,.preview-phone .unmute{width:30px;height:100%;background-size:20px}.preview-phone .mute{background:url(/images/mute.svg) no-repeat 50%}.preview-phone .unmute{background:url(/images/unmute.svg) no-repeat 50%}.preview-phone .remove-transform{transform:none!important}.preview-phone .together-module{padding:0 2px;font-size:0}.preview-phone .together-link{vertical-align:middle;display:inline-block;padding:0 2px 5px}.preview-phone .together-link img{width:100%}.preview-phone .pic-module{width:100%;display:block}.preview-phone .recommend-title-wrapper{height:42px;line-height:42px;text-align:center}.preview-phone .recommend-title-wrapper:after{content:"";line-height:0;height:1px;width:50%;background-color:#ccc;display:block;margin:-22px auto 0}.preview-phone .recommend-title-wrapper .recommend-title{padding:0 10px;background-color:#fff;display:inline-block;font-size:16px}.preview-phone .first-image{padding:0;text-align:center;font-size:0;position:relative;bottom:0}.preview-phone .ec-validate{color:#ff4949;font-size:12px;line-height:1;padding-top:4px}.ec-input{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:#fff;border-radius:4px;border:1px solid #c5c5c5;display:block;font-size:inherit;height:36px;line-height:1;padding:3px 10px;width:100%}.verify-btn{display:inline-block;width:40%;text-align:center;line-height:36px;border-radius:4px;background-color:#e8e8e8;color:#666}.verify-close{position:absolute;top:10px;right:10px;font-size:30px;color:#999;width:30px;height:30px;text-align:center;line-height:30px}.fade-out{opacity:0!important;visibility:hidden!important}.pc{width:640px;background-color:#fff;margin:0 auto}.pc .preview-phone{margin-top:35px}.hide{display:none!important}.weui-toast.remind{min-height:0;width:auto;padding:0 20px;transform:translate(-50%);left:50%;margin-left:0}.weui-toast.remind .weui-icon_toast{display:none}.weui-toast.remind .weui-toast__content{vertical-align:middle;padding-top:20px}.detail-tab .section>div,.detail-tab>input{display:none}#tab1:checked~.section .tab1,#tab2:checked~.section .tab2{display:block}#tab2:checked~.section .tab2{padding:0 8px}#tab2:checked~.section .tab2 label{display:block;border-bottom:1px solid #eee}#tab2:checked~.section .tab2 .title{font-size:16px;line-height:40px;position:relative}#tab2:checked~.section .tab2 .title:after{content:" ";display:inline-block;height:6px;width:6px;border-width:2px 2px 0 0;border-color:#999;border-style:solid;transform:rotate(45deg);position:absolute;top:50%;margin-top:-4px;right:2px;transition:transform .7s}#tab2:checked~.section .tab2 input:checked~.title:after{transform:rotate(135deg)}#tab2:checked~.section .tab2 input{display:none}#tab2:checked~.section .tab2 .content{max-height:0;transition:max-height .7s;overflow:hidden;line-height:30px;padding-left:16px}#tab2:checked~.section .tab2 input:checked~.content-1{max-height:180px}#tab2:checked~.section .tab2 input:checked~.content-2{max-height:320px}#tab2:checked~.section .tab2 input:checked~.content-3{max-height:60px}#tab2:checked~.section .tab2 input:checked~.content-4{max-height:90px}.detail-tab{}.detail-tab .section{margin:15px 0}.detail-tab ul.nav{list-style:none;padding:0 15%;font-size:16px}.detail-tab ul.nav .tab1,.detail-tab ul.nav .tab2{width:50%;float:left;text-align:center}.detail-tab ul.nav .tab1 label,.detail-tab ul.nav .tab2 label{display:inline-block;padding:15px 0 5px}</style>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.4.3.min.js" ></script>
<script type="text/javascript" src="storeOrder.js" ></script>
<meta http-equiv="Content-Type"'.
    ' content="text/html; charset=utf-8"/>
</head>
<body class="pc">
<form method="post" id="addorder">
<div class="first-image">


</div>
<div id="marketingModules">
<style inject="" type="text/css">.marquee-wrapper{pointer-events:none;height:36px;margin-top:-36px;position:relative;z-index:2}.marquee-wrapper.fix{position:fixed;top:10px;width:100%;left:0;right:0;margin-top:0}.marquee-wrapper #marqueeContainer{position:relative;margin:0;padding:0;list-style:none}.marquee-wrapper #marqueeContainer li{list-style:none;position:absolute;left:0;margin:5px 10px 5px 5px;padding:0 10px 0 1px;border-radius:15px;height:26px;line-height:26px;font-size:14px;opacity:1;width:auto;box-shadow:0 0 4px rgba(0,0,0,.5)}.marquee-wrapper #marqueeContainer li span{display:inline-block;margin-left:-16px}.marquee-wrapper #marqueeContainer li div{width:44px;height:44px;float:left;background:url(/images/head-sprites.png) no-repeat;transform:translateY(2px) scale(.5);transform-origin:0 0}.marquee-wrapper .marquee-style-1 li{background-color:#fff;color:#000}.marquee-wrapper .marquee-style-2 li{background-color:rgba(0,0,0,.9);color:#fff}.pc .marquee-wrapper.fix{left:50%;margin-left:-320px}</style>

<style inject="" type="text/css">@font-face{font-family:tencentW7;src:url("/dist/tencent-w7-merge.ttf") format("truetype")}.campaign{height:80px;background:#eb3b39 url("/images/618bg.png") no-repeat 0;background-size:contain;position:relative}.campaign,.campaign .left{display:-ms-flexbox;display:flex}.campaign .left{font-family:tencentW7;-ms-flex-positive:1;flex-grow:1;color:#fff;text-align:center;-ms-flex-align:center;align-items:center;-ms-flex-direction:column;flex-direction:column;padding-top:12px}.campaign .left .logo img{height:26px}.campaign .left .text{font-size:22px;line-height:22px}.campaign .left .text:before{content:"";display:inline-block;width:15px;height:2px;margin-right:3px;background-color:#fff;vertical-align:middle}.campaign .right{-ms-flex-positive:1;flex-grow:1;display:-ms-flexbox;display:flex;text-align:center;-ms-flex-direction:column;flex-direction:column;color:#fff;position:relative;padding-right:8px}.campaign .right .time{border:1px solid #eb3b39;border-top-right-radius:6px;border-bottom-right-radius:6px;border-bottom-left-radius:6px;background-color:#fff;color:#eb3b39;margin-top:-10px;height:60px;text-align:center;box-shadow:1px 1px 4px 0 rgba(0,0,0,.6);position:relative;z-index:1;overflow:hidden;padding:0 5px}.campaign .right .time .clock-wrap{font-family:tencentW7;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;position:relative;z-index:1;margin:0 auto;padding-top:4px}.campaign .right .time .clock{display:-ms-flexbox;display:flex;-ms-flex-pack:distribute;justify-content:space-around;font-size:22px;line-height:30px}.campaign .right .time .clock span{width:14px;display:inline-block}.campaign .right .time .clock .no-bg,.campaign .right .time .unit .no-bg{display:inline-block;font-size:16px}.campaign .right .time .unit .no-bg{opacity:0}.campaign .right .time .clock .block{display:inline-block}.campaign .right .time .unit{line-height:16px;font-size:14px;display:-ms-flexbox;display:flex;-ms-flex-pack:distribute;justify-content:space-around}.campaign .right .time .unit span{display:inline-block;width:28px}.campaign .right .time .yellow-triangle{position:absolute;width:24px;height:21px;top:38px;left:6px;background:url(/images/yellow-triangle.png) no-repeat;background-size:60%}.campaign .right .time .blue-triangle{position:absolute;width:25px;height:25px;top:7px;right:23px;background:url(/images/blue-triangle.png) no-repeat;background-size:62%}.campaign .right .time .sprite{position:absolute;width:30px;height:30px;background-repeat:no-repeat;background-size:50%}.campaign .right .triangle{position:absolute;height:10px;width:10px;top:-10px;left:-10px;overflow:hidden}.campaign .right .triangle:before{content:"";display:block;background-color:#fff;border:1px solid #eb3b39;width:20px;height:20px;transform:translateX(5px) rotate(30deg)}.campaign .right .tip{line-height:30px;font-size:12px;opacity:.75}.campaign .right .tip span{padding:0 5px}</style>


<style inject="" type="text/css">.good-hot-wrapper{font-size:20px;line-height:20px;padding:15px 8px 0}.good-hot-wrapper span{color:#666;display:inline-block;margin-right:3px;font-size:14px}.good-price{font-size:20px;padding:15px 8px 0;float:left;line-height:20px}.good-price .cross-price{text-decoration:line-through;font-size:14px;color:#666}</style>


<style inject="" type="text/css">.page-title{position:relative;font-size:15px;line-height:22px;text-align:left;border-bottom:1px solid #e5e5e5;padding:10px 8px 15px;word-wrap:break-word;word-break:break-all}.page-title p{text-indent:40px;letter-spacing:1px}.page-title span.icon{position:absolute;left:8px;top:12px;font-size:12px;font-weight:400;background:#fc2d44;color:#fff;padding:0 5px;line-height:18px;border-radius:10px}</style>

<style inject="" type="text/css">.good-services{font-size:12px;margin-top:15px;border-bottom:1px solid #e5e5e5;padding:0 0 15px}.good-services .item{float:left;text-align:center;width:33.3%}.good-services .item .span-icon{display:inline-block;margin-right:3px;height:16px;vertical-align:sub}</style>


<style inject="" type="text/css">.price-buy-wrapper{margin:15px 8px;border-radius:4px;font-size:18px;overflow:hidden}.price-buy-wrapper .index-buying{display:block;text-align:center}</style>

<style>
                #tab1:checked ~ .nav .tab1 label, #tab2:checked ~ .nav .tab2 label {
                    color: #ff0038;
                    border-bottom: 2px solid #ff0038;
                }
            </style>

</div>
<style inject="" type="text/css">#ec-form-wrapper{font-style:normal}#ec-form-wrapper li{list-style:none}#ec-form-wrapper .ec-form-fields{background:#f6f7f8;border:1px solid #e7e8e9;border-radius:4px;font-size:15px;margin:0 8px}#ec-form-wrapper .item-group{border-bottom:1px solid #e7e8e9;padding:10px 14px}#ec-form-wrapper .item-group:first-child{padding-bottom:0}#ec-form-wrapper .title{font-weight:700;color:#333}#ec-form-wrapper .ec-input{border:none;background-color:transparent;padding:0}#ec-form-wrapper .coupon-label{background:url("/images/coupon-icon.svg") no-repeat 100%;margin-bottom:10px;display:inline-block;padding-right:26px;line-height:22px}#ec-form-wrapper .ec-label{text-align:left;vertical-align:middle;float:left;line-height:36px;width:83px}#ec-form-wrapper .ec-content{line-height:36px;position:relative;margin-left:84px}#ec-form-wrapper .select-area>select{width:100%;height:36px;border:0;font-size:inherit;background-color:transparent}#ec-form-wrapper .attribute-name{margin-top:10px}#ec-form-wrapper .ec-validate{display:block;padding-top:0;line-height:14px}#ec-form-wrapper .select-wrapper{display:inline-block;width:33%;margin-left:0;padding-right:5px}#ec-form-wrapper #fill-forms{height:60px;line-height:50px;font-size:16px;text-align:center;}#ec-form-wrapper .submit-button{display:block;color:#fff;background:#cf2a4f;height:30px;line-height:30px;text-align:center;margin:15px 8px;border-radius:4px;font-size:16px}#ec-form-wrapper .pay-doc{padding:8px 10px;border-radius:4px}@media (max-width:320px){#ec-form-wrapper .pay-doc{padding:8px 7px}}#ec-form-wrapper .package-group,#ec-form-wrapper .prop-list{margin-top:10px}#ec-form-wrapper .package-group>li,#ec-form-wrapper .prop-list>li{float:left;background-color:#fff;line-height:20px;border:1px solid #dbdee4;border-radius:4px;color:#333;padding:8px 10px;margin:0 10px 10px 0;cursor:pointer}#ec-form-wrapper .package-group>li.active,#ec-form-wrapper .prop-list>li.active{color:#fff;border-color:#cf2a4f;background-color:#cf2a4f}#ec-form-wrapper .ec-spinner{text-align:center}#ec-form-wrapper .ec-spinner .left,#ec-form-wrapper .ec-spinner .right{float:left;line-height:34px;width:36px;font-size:18px;background-color:#fff;border-radius:4px;border:1px solid #e7e8e9;cursor:pointer}#ec-form-wrapper .ec-spinner .left.disabled,#ec-form-wrapper .ec-spinner .right.disabled{color:#c5c5c5}#ec-form-wrapper .is-required:before{content:"*";color:#ff4949;display:inline-block;width:10px;margin-left:-10px}#ec-form-wrapper .pic-prop{clear:both;width:160px;height:160px;margin:0 auto 20px;overflow:hidden;background-repeat:no-repeat;background-size:cover}.custom-checkbox{display:block;position:relative;padding-left:20px;font-size:14px}.custom-checkbox input{opacity:0;height:0;width:0}.custom-checkbox .check-mark{position:absolute;top:0;left:0;height:14px;width:14px;border:1px solid #777;border-radius:2px}.custom-checkbox input:checked~.check-mark:after{display:block}.custom-checkbox .check-mark:after{content:"";position:absolute;display:none;left:4px;top:1px;width:3px;height:7px;border:solid #333;border-width:0 2px 2px 0;transform:rotate(45deg)}</style>
<style>
    #ec-form-wrapper .package-group > li.active {
        color: #ffffff;
        border: 1px solid #ff0038;
        background-color: #ff0038;
    }
    #ec-form-wrapper .prop-list > li.active {
        color: #ffffff;
        background-color: #ff0038;
        border-color: #ff0038;
    }
</style>
<div id="ec-form-wrapper">
<div id="fill-forms">Order</div>
<div class="ec-form-fields">
<div class="item-group clear">
<div>Commodity</div>
<ul class="package-group">
<li data-package="1" class="active price" data-price="698.00">
Model 1#：4k超清录像1080P+送VR眼镜698元
</li>
<li data-package="2" class="price" data-price="598.00">
Model 2#：2k高清录像720P+送VR眼镜598元
</li>
<li data-package="3" class="price" data-price="498.00">
Model #3：1k标清录像+送VR眼镜498元
</li>
</ul>
</div>
<div data-package-detail="0" class="item-group clear ">
<div data-product="0_0" data-name="手势拍照、双镜头切换、光流定位、人影跟随！" class="title clear" style="margin-bottom: 10px">Desceiption</div>
<p id="attribute-name-0_0_0" class="is-required attribute-name">Color
<span data-attribute-validate="0_0_0" class="ec-validate hide" style="display: inline;">pick up color</span>
</p>
<ul class="prop-list">
<li data-attribute="0_0_0" data-index="0" data-value="black" class="color">
black
</li>
<li data-attribute="0_0_0" data-index="1" data-value="white" class="color">
white
</li>
</ul>
<div class="clear"></div>
</div>
<div data-package-detail="1" class="item-group clear hide">
<div data-product="1_0" data-name="手势拍照、双镜头切换、光流定位、人影跟随！" class="title clear" style="margin-bottom: 10px">Description</div>
<p id="attribute-name-1_0_0" class="is-required attribute-name">Color
<span data-attribute-validate="1_0_0" class="ec-validate hide" style="display: inline;">请选择颜色</span>
</p>
<ul class="prop-list">
<li data-attribute="1_0_0" data-index="0" data-value="black">
black
</li>
<li data-attribute="1_0_0" data-index="1" data-value="white">
white
</li>
</ul>
<div class="clear"></div>
</div>
<div data-package-detail="2" class="item-group clear hide">
<div data-product="2_0" data-name="手势拍照、双镜头切换、光流定位、人影跟随！" class="title clear" style="margin-bottom: 10px">手势拍照、双镜头切换、光流定位、人影跟随！</div>
<p id="attribute-name-2_0_0" class="is-required attribute-name">color
<span data-attribute-validate="2_0_0" class="ec-validate hide" style="display: inline;">pickup color</span>
</p>
<ul class="prop-list">
<li data-attribute="2_0_0" data-index="0" data-value="black" class="color">
black
</li>
<li data-attribute="2_0_0" data-index="1" data-value="white" class="color">
white
</li>
</ul>
<div class="clear"></div>
</div>
<div class="item-group clear">
<label class="ec-label">Quantity</label>
<div id="package-spinner" class="ec-spinner">
<i data-type="left" class="left " style="font-style: normal;">-</i>
<div style="width:36px;line-height:36px;float:left;" id="package-amount">1</div>
<i data-type="right" class="right" style="font-style: normal;">+</i>
</div>
<div style="text-align: right; line-height: 36px;">Total <span style="color: #ff0038">￥</span><span style="color: #ff0038; font-weight: bold;" id="couponTotalPrice"> 0 </span></div>
</div>
<div class="item-group">
<label class="ec-label is-required">Name</label>
<div class="ec-content">
<input id="name" type="text" class="ec-input" maxlength="10" placeholder="your name" name="name" required>
<div for="name" class="ec-validate"></div>
</div>
</div>
<div class="item-group">
<label class="ec-label is-required" required>Phone</label>
<div class="ec-content">
<input id="phone" type="tel" class="ec-input" placeholder="your phone number" name="phone">
<div for="phone" class="ec-validate"></div>
</div>
</div>
<div class="item-group" id="select-area">
<label class="ec-label is-required">address</label>
<div class="ec-content">
<div class="select-area select-wrapper">
<select id="province" name="province" >
    
</select>
</div><div class="select-area select-wrapper">
<select id="city" name="city">
    
</select>
</div><div class="select-area select-wrapper">
<select id="area" name="region">
   
</select>
</div>
<div for="area" class="ec-validate"></div>
</div>
</div>
<div class="item-group">
<label class="ec-label is-required">street</label>
<div class="ec-content">
<input id="addressdetail" placeholder="addressdetail" type="text" class="ec-input" maxlength="50" name="address">
<div for="addressdetail" class="ec-validate"></div>
</div>
</div>
<div class="item-group">
  <p id="attribute-name-2_0_0" class="is-required attribute-name">Payment
  <span data-attribute-validate="2_0_0" class="ec-validate hide" style="display: inline;">pickup color</span>
  </p>
  <ul class="prop-list">
  <li data-attribute="2_0_0" data-index="0" data-value="Paypal" class="payment">
Paypal
  </li>
  <li data-attribute="2_0_0" data-index="1" data-value="Visa" class="payment">
Visa
  </li>
</li>
<li data-attribute="2_0_0" data-index="1" data-value="Master" class="payment">
Master
</li>
  <li data-attribute="2_0_0" data-index="1" data-value="debit card" class="payment">
debit card
  </li>
  </ul>
  <div class="clear"></div>

</div>
<div class="item-group">
<label class="ec-label required-placeholder" style="line-height: 1; padding-top: 10px;">Message</label>
<div class="ec-content">
<textarea id="message" class="ec-input" style="height: 60px; padding-top: 10px;" maxlength="100" placeholder="left your message here" name="message"></textarea>
</div>
</div>
<div class="item-group" style="line-height: 14px;">
<label class="custom-checkbox">store address for automatically fill in next time
<input type="checkbox" id="cookiecheck" checked="checked">
<span class="check-mark"></span>
</label>
</div>
</div>
<button type="submit" id="" class="submit-button" style="
            color: #ffffff;
            background-color: #ff0038;
            height: 46px;
            line-height: 46px;
            width: 100%;
            padding: 5px;
            cursor: pointer;
            ">
Submit
</button>
</div>

<div style="margin: 15px 0; font-size: 16px; text-align: center;">
<div style="font-size: 14px;line-height: 30px;">cnszTech Support</div>
<div style="font-size: 14px;line-height: 30px;" id="fyBrand"><script>document.write(window.location.host)</script>仅提供技术支持</div>
</div>

</form>
</body>
</html>
<script type="text/javascript">
        window.EC = {"packageList":[{"id":224362,"name":"\u9876\u914d\u7248\uff1a4k\u8d85\u6e05\u5f55\u50cf1080P+\u9001VR\u773c\u955c698\u5143","price":"698.00","productList":[{"id":225075,"name":"\u624b\u52bf\u62cd\u7167\u3001\u53cc\u955c\u5934\u5207\u6362\u3001\u5149\u6d41\u5b9a\u4f4d\u3001\u4eba\u5f71\u8ddf\u968f\uff01","productAttributeList":[{"id":218539,"name":"\u989c\u8272","module":"txt","attributeValue":["\u9ed1\u8272","\u767d\u8272"]}]}]},{"id":224363,"name":"\u9ad8\u914d\u7248\uff1a2k\u9ad8\u6e05\u5f55\u50cf720P+\u9001VR\u773c\u955c598\u5143","price":"598.00","productList":[{"id":225076,"name":"\u624b\u52bf\u62cd\u7167\u3001\u53cc\u955c\u5934\u5207\u6362\u3001\u5149\u6d41\u5b9a\u4f4d\u3001\u4eba\u5f71\u8ddf\u968f\uff01","productAttributeList":[{"id":218540,"name":"\u989c\u8272","module":"txt","attributeValue":["\u9ed1\u8272","\u767d\u8272"]}]}]},{"id":224364,"name":"\u6807\u914d\u7248\uff1a1k\u6807\u6e05\u5f55\u50cf+\u9001VR\u773c\u955c498\u5143","price":"498.00","productList":[{"id":225077,"name":"\u624b\u52bf\u62cd\u7167\u3001\u53cc\u955c\u5934\u5207\u6362\u3001\u5149\u6d41\u5b9a\u4f4d\u3001\u4eba\u5f71\u8ddf\u968f\uff01","productAttributeList":[{"id":218541,"name":"\u989c\u8272","module":"txt","attributeValue":["\u9ed1\u8272","\u767d\u8272"]}]}]}],"coupon":{"enable":"","type":"1","list":[],"style":"1","id":122098},"rId":"173741250_730f7cc49","gId":"173741250","gName":"\u6b64\u9875\u9762\u4e0b\u5355\u4ec51\u6298\u2014\u2014\u9ad8\u79d1\u6280\u822a\u62cd\u65e0\u4eba\u673a","version_g_id":"1737206607","account_id":"10759737","isPublish":true,"mainPic":"https:\/\/p2.qpic.cn\/fengye\/0\/apd_1829463965ce4badd00b20\/0?800*800","title":"\u6b64\u9875\u9762\u4e0b\u5355\u4ec51\u6298\u2014\u2014\u9ad8\u6e05\u822a\u62cd\u65e0\u4eba\u673a","goodsType":"\u822a\u62cd\u65e0\u4eba\u673a","statHost":"stat.fyeds7.com","host":"ec.fy.qq.com","isTogether":false,"fromAdmin":false,"isMobile":false,"isSMSVerifyOpen":false,"ecfrom":"","indexPicSpeed":2000,"goodsTypeId":"101459","systemConfig":{"grey":"1","grey_uid_list":[""],"grey_uid_postfix_list":[""],"editor_show":"0","editor_show_message":"\u529f\u80fd\u5347\u7ea7\u4e2d\uff0c\u8bf7\u7a0d\u5019","play_close_mp_share":"0","play_close_marquee":"0","play_close_ip_location":"0","play_close_refresh_token":"0"}};

        
    </script>

<script type="text/javascript" src="files/region.min.js" ></script>
<script type="text/javascript" src="files/mobile.js"></script>

